#include "OpenCVWrapper.h"


/*!
 * @brief cv::distanceTransform�̃��b�p�[�֐�
 */
void distanceTransformWrapper( const cv::Mat& src, cv::Mat& dst, int distanceType, int maskSize )
{
	cv::distanceTransform( src, dst, distanceType, maskSize );
}

/*!
 * @brief cv::distanceTransform�̃��b�p�[�֐�
 */
void distanceTransformWrapperWithLabels( const cv::Mat& src, cv::Mat& dst, cv::Mat& labels, int distanceType, int maskSize, int labelType )
{
	cv::distanceTransform( src, dst, labels, distanceType, maskSize, labelType );
}

/*!
 * @brief cv::imshow�̃��b�p�[�֐�
 */
void show_image( const std::string& win_name, const cv::Mat& src )
{
	cv::imshow( win_name, src );
	cv::waitKey(1);
}
