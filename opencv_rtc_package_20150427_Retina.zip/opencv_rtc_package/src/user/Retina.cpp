#include "Retina.h"

void cvRetina(cv::Mat& src,	cv::Mat& magno,cv::Mat& parvo, int log_sampling)
{
	static int prev_log_sampling = abs(log_sampling-1);
	static cv::Ptr<cv::Retina> retina_image;
	
	if((log_sampling+prev_log_sampling)%2){
		retina_image.release();
		if(log_sampling){
		
			retina_image = new cv::Retina(src.size());
		
		}
		else{
			retina_image = new cv::Retina(src.size(), true, cv::RETINA_COLOR_BAYER, true, 2.0, 10.0);
		}
		prev_log_sampling = log_sampling;
	}
	
	retina_image->run(src);
	retina_image->getParvo(parvo);
	retina_image->getMagno(magno);
}
