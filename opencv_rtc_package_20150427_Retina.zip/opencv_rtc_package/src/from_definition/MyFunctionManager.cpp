// This file is created automatically.
#include <iostream>
#include <opencv2/opencv.hpp>
#include "OpenCVWrapper.h"
#include "OpenCVRTCUtil.h"
#include "Retina.h"
#include <MyFunctionManager.h>

#include <load_image_seq_default.h>
#include <save_image_seq_default.h>
#include <cvRetina_default.h>
using namespace cv;
using namespace std;


MyFunctionManager::MyFunctionManager()
    : FunctionManager()
{}

MyFunctionManager::~MyFunctionManager()
{}


bool MyFunctionManager::initialize(RTC::RTObject_impl &object)
{

	// load_image_seq function
	registerFunction( 
		FuncPtr( new load_image_seq_default(object, "load_image_seq", load_image_seq,
		ParameterT<void>("return","unused",""),
		ParameterT<std::string&>("file_name","param","","image/lena.jpg",""),
		ParameterT<cv::Mat&>("dst","outport","",cv::Mat(),""),
		ParameterT<int&>("num","param","",0,"")
	)));

	// save_image_seq function
	registerFunction( 
		FuncPtr( new save_image_seq_default(object, "save_image_seq", save_image_seq,
		ParameterT<void>("return","unused",""),
		ParameterT<std::string&>("file_name","param","","output.jpg",""),
		ParameterT<cv::Mat&>("src","inport","",cv::Mat(),""),
		ParameterT<int&>("num","param","",0,"")
	)));

	// cvRetina function
	registerFunction( 
		FuncPtr( new cvRetina_default(object, "cvRetina", cvRetina,
		ParameterT<void>("return","unused",""),
		ParameterT<cv::Mat&>("src","inport","",cv::Mat(),""),
		ParameterT<cv::Mat&>("magno","outport","",cv::Mat(),""),
		ParameterT<cv::Mat&>("parvo","outport","",cv::Mat(),""),
		ParameterT<int>("log_sampling","list","ON:1,OFF:0",0,"OFF:0")
	)));
    return true;
}

/* Compile functions class defined. */
#include <load_image_seq_default.cpp>
#include <save_image_seq_default.cpp>
#include <cvRetina_default.cpp>
