// This file is created automatically.

#include <ConfigurationManager.h>
#include <ConfigurationHolder.h>
#include <MyConfigurationManager.h>

using namespace std;

bool MyConfigurationManager::initialize()
{
    return true;
}
