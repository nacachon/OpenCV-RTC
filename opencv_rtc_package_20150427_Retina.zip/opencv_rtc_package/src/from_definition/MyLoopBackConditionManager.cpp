// This file is created automatically.

#include <boost/format.hpp>
#include <StepwiseSystem.h>
#include <MyLoopBackConditionManager.h>
#include <MyLoopBackCondition.h>
#include <MatrixUtil.h>

using namespace cv;
using namespace std;

MyLoopBackConditionManager::~MyLoopBackConditionManager(){
    delete condition;
};

void MyLoopBackConditionManager::initialize(std::string &func_name)
{
    if ( func_name == "load_image_seq" ) {
        condition = new LoopBackConditionload_image_seq_default(object);
    }
    if ( func_name == "save_image_seq" ) {
        condition = new LoopBackConditionsave_image_seq_default(object);
    }
    if ( func_name == "cvRetina" ) {
        condition = new LoopBackConditioncvRetina_default(object);
    }
}

bool MyLoopBackConditionManager::useInitialData( const std::string &inport_name )
{
    return condition->useInitialData(inport_name);
}
    
void MyLoopBackConditionManager::getInitialData( const std::string &inport_name )
{
    condition->getInitialData(inport_name);
}

bool LoopBackConditionload_image_seq_default::useInitialData( const std::string & portname )
{
    bool useInitialData = false;

    return useInitialData;
}
void LoopBackConditionload_image_seq_default::getInitialData( const std::string & portname )
{
}

bool LoopBackConditionsave_image_seq_default::useInitialData( const std::string & portname )
{
    bool useInitialData = false;

    if ( portname == (boost::format("%s.src")%object.getInstanceName()).str() ) {
    }
    return useInitialData;
}
void LoopBackConditionsave_image_seq_default::getInitialData( const std::string & portname )
{
    if ( portname == (boost::format("%s.src")%object.getInstanceName()).str() ) {
        
    }
}

bool LoopBackConditioncvRetina_default::useInitialData( const std::string & portname )
{
    bool useInitialData = false;

    if ( portname == (boost::format("%s.src")%object.getInstanceName()).str() ) {
    }
    return useInitialData;
}
void LoopBackConditioncvRetina_default::getInitialData( const std::string & portname )
{
    if ( portname == (boost::format("%s.src")%object.getInstanceName()).str() ) {
        
    }
}

