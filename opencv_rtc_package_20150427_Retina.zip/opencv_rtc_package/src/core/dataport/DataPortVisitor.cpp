#include <iostream>
#include "DataPortVisitor.h"
#include "Parameter.h"

DataPortVisitor::DataPortVisitor()
{}

DataPortVisitor::~DataPortVisitor()
{}

void DataPortVisitor::visit( ParameterBase& param )
{
	std::cerr << param.getType().name() << "is unknown data type" << std::endl;
}