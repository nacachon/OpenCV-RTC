// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file StepwiseExecutionContextSkel.cpp 
 * @brief StepwiseExecutionContext server skeleton wrapper
 * @date Mon Jul 07 13:33:37 2014 
 *
 */

#include "StepwiseExecutionContextSkel.h"

#if defined ORB_IS_TAO
#  include "StepwiseExecutionContextC.cpp"
#  include "StepwiseExecutionContextS.cpp"
#elif defined ORB_IS_OMNIORB
#  include "StepwiseExecutionContextSK.cc"
#  include "StepwiseExecutionContextDynSK.cc"
#elif defined ORB_IS_MICO
#  include "StepwiseExecutionContext.cc"
#  include "StepwiseExecutionContext_skel.cc"
#elif defined ORB_IS_ORBIT2
#  include "StepwiseExecutionContext-cpp-stubs.cc"
#  include "StepwiseExecutionContext-cpp-skels.cc"
#elif defined ORB_IS_RTORB
#  include "OpenRTM-aist-decls.h"
#  include "StepwiseExecutionContext-common.c"
#  include "StepwiseExecutionContext-stubs.c"
#  include "StepwiseExecutionContext-skels.c"
#  include "StepwiseExecutionContext-skelimpl.c"
#else
#  error "NO ORB defined"
#endif

// end of StepwiseExecutionContextSkel.cpp
