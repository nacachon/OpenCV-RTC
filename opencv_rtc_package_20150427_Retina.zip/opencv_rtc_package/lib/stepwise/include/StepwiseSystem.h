// -*- C++ -*-
/*!
 * @file StepwiseSystem.h
 * @brief ���[�U�[�����}�N����`
 * @date $Date: 2008-01-14 07:53:05 $
 * @author 
 *
 * $Id: $
 *
 */
#ifndef _STEPWISE_SYSTEM_H_
#define _STEPWISE_SYSTEM_H_

#include "StepwiseUtility.h"

/* --------------------------- */
/* ���[�U�[�p�}�N��             */
/* --------------------------- */
/* ���s�񐔎擾 */
#define STEPWISE_GET_COMMON_STEP_COUNTER()          StepwiseUtility::getCommonStepCounter()
#define STEPWISE_GET_INDIVIDUAL_STEP_COUNTER(obj)   StepwiseUtility::getIndividualStepCounter(obj)

/* �J�E���^���Z�b�g */
#define STEPWISE_RESET_COMMON_STEP_COUNTER()        StepwiseUtility::resetCommonStepCounter()
#define STEPWISE_RESET_INDIVIDUAL_STEP_COUNTER()    StepwiseUtility::resetIndividualStepCounter(this)

/* �ꎞ��~ */
#define STEPWISE_PAUSE_EXECUTION()                  StepwiseUtility::pauseExecution()

/* ���s�ĊJ(�ꎞ��~����) */
#define STEPWISE_RESUME_EXECUTION()                 StepwiseUtility::resumeExecution()

/* ���s�񐔎w�� */
#define STEPWISE_SET_STEP_COUNTER_UP_TO_SUS(count)  StepwiseUtility::setStepCounterUpToSus( count )
#define STEPWISE_RESET_STEP_COUNTER_UP_TO_SUS()     StepwiseUtility::resetStepCounterUpToSus()

/* ���s��Ԏ擾 */
#define STEPWISE_GET_EVERY_COMPONENT_STATUS()       StepwiseUtility::getEveryComponentStatus()

/* �f�[�^�҂��ʒm */
#define STEPWISE_NOTIFY_NO_DATA()                   StepwiseUtility::notifyNoData(this)

#endif // _STEPWISE_SYSTEM_H_
