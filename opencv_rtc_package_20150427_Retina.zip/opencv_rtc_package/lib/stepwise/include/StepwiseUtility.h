// -*- C++ -*-
/*!
 * @file StepwiseUtility
 * @brief StepwiseExecutionContext class
 * @date $Date: 2008-01-14 07:53:05 $
 * @author 
 *
 * $Id: $
 *
 */

#ifndef RTC_STEPWISEUTILITY_H
#define RTC_STEPWISEUTILITY_H

#include <rtm/RTC.h>
#include <rtm/RTObject.h>

#include "StepwiseExecutionContext.h"
#include "NamingServiceAccessor.h"

namespace RTC
{
  class StepwiseUtility
  {
  public:
    /* �V�X�e�����s��Ԏ擾 */
    static StepwiseStatus getStepwiseStatus();
    
    /* �Ǘ��ΏۃR���|�[�l���g�ꗗ�擾 */
    static TargetCompList *getTargetComponents();
    
    /* ���s�񐔎擾 */
    static long getCommonStepCounter();
    static long getIndividualStepCounter( RTObject_impl *rtobj );
    
    /* �J�E���^���Z�b�g */
    static void resetCommonStepCounter();
    static void resetIndividualStepCounter( RTObject_impl *rtobj );
    
    /* �ꎞ��~ */
    static void pauseExecution();
    
    /* ���s�ĊJ(�ꎞ��~����) */
    static void resumeExecution();
    
    /* ���s�񐔎w�� */
    static void setStepCounterUpToSus( double count );
    static void resetStepCounterUpToSus();
    
    /* ���s��Ԏ擾 */
    static StepwiseSystemExecInfo * getEveryComponentStatus();
    
    /* �f�[�^�҂��ʒm */
    static void notifyNoData(RTObject_impl *rtobj);

    /* �R���|�[�l���g�폜 */
    static void removeFromTarget( const std::string &namingname );

    static StepwiseExecutionContextService_ptr getMasterStepwiseExecutionContextService();

    static StepwiseExecutionContextService_ptr getStepwiseExecutionContextService( RTC::LightweightRTObject_ptr &rtcObjp );

    static std::vector<std::string> getRtcList();

    static RTC::LightweightRTObject_ptr getActiveRTObject( std::string &namingname );

    static RTC::ExecutionContext_ptr getOwnedEC( RTC::LightweightRTObject_ptr rtcObjp );

    static bool isStepwiseMaster( RTC::ExecutionContext_ptr ec, std::string &ior );

    static ExecutionContextProfile * getExecutionContextProfile ( RTC::ExecutionContext_ptr ec );

    static StepwiseExecutionContextService_ptr getStepwiseExecutionContextService(ExecutionContextProfile &ecp);

  private:

    static NamingServiceAccessor &getNSAccessor();

    static StepwiseExecutionContextService_ptr m_masterSwecServ;

    static NamingServiceAccessor * m_pNsAccess;

    static Logger rtclog;


  }; // class StepwiseUtility
}; // namespace RTC


extern "C"
{
  int WorkSize(void);
};

#endif // RTC_STEPWISEUTILITY_H
