// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file StepwiseExecutionContextStub.h 
 * @brief StepwiseExecutionContext client stub header wrapper code
 * @date Mon Jul 07 13:33:37 2014 
 *
 */

#ifndef _STEPWISEEXECUTIONCONTEXTSTUB_H
#define _STEPWISEEXECUTIONCONTEXTSTUB_H



#include <rtm/config_rtc.h>
#undef PACKAGE_BUGREPORT
#undef PACKAGE_NAME
#undef PACKAGE_STRING
#undef PACKAGE_TARNAME
#undef PACKAGE_VERSION

#if   defined ORB_IS_TAO
#  include "StepwiseExecutionContextC.h"
#elif defined ORB_IS_OMNIORB
#  if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
#    undef USE_stub_in_nt_dll
#  endif
#  include "StepwiseExecutionContext.hh"
#elif defined ORB_IS_MICO
#  include "StepwiseExecutionContext.h"
#elif defined ORB_IS_ORBIT2
#  include "StepwiseExecutionContext-cpp-stubs.h"
#elif defined ORB_IS_RTORB
#  include "StepwiseExecutionContext.h"
#else
#  error "NO ORB defined"
#endif

#endif // _STEPWISEEXECUTIONCONTEXTSTUB_H
