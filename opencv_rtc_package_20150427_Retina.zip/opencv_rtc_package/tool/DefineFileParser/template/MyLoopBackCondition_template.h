// This file is created automatically.

#ifndef _MYLOOPBACKCONDITIONMANAGER_H_
#define _MYLOOPBACKCONDITIONMANAGER_H_

#include <LoopBackCondition.h>

% for function in functions
class LoopBackCondition${function.name} : public LoopBackCondition
{
public:
    LoopBackCondition${function.name}(RTC::RTObject_impl &obj)
        : LoopBackCondition( obj ){};
    virtual ~LoopBackCondition${function.name}(){};
    bool useInitialData( const std::string & portname );
    void getInitialData( const std::string & portname );
};

% endfor

#endif // _MYLOOPBACKCONDITIONMANAGER_H_
