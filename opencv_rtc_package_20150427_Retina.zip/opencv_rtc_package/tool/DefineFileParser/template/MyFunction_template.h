#ifndef _${func.classname}_H
#define _${func.classname}_H

#include <Function.h>

using namespace std;
using namespace cv;

class ${func.classname}:
  public  Function<${func.type}>
{
public:
    /*!
     * @brief Constructor
     * @param[in] name  PortName
     * @param[in] param 
     */
    ${func.classname}( 
        RTC::RTObject_impl& obj,
        const std::string& name,
        FuncType func,
% for param in func.params
        ${param}
% endfor
        ) : 
        Function<${func.type}>(obj, name, func, ${constructorparam})
    {};

    virtual RTC::ReturnCode_t onInitialize();
    virtual RTC::ReturnCode_t onStartup();
    virtual RTC::ReturnCode_t onActivated();
    virtual RTC::ReturnCode_t onDeactivated();
    virtual RTC::ReturnCode_t onShutdown();
    virtual RTC::ReturnCode_t onFinalize();
    virtual RTC::ReturnCode_t onAborting();
    virtual RTC::ReturnCode_t onError();
    virtual RTC::ReturnCode_t onReset();
    virtual RTC::ReturnCode_t onStateUpdate();
    virtual RTC::ReturnCode_t onRateChanged();

};

#endif // _${func.classname}_H

