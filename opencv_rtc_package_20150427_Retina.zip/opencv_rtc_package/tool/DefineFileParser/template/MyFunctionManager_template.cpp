// This file is created automatically.
% for include in includes
${include}
%endfor
#include <MyFunctionManager.h>

% for func in functions
#include <${func.classname}.h>
% endfor

using namespace cv;
using namespace std;


MyFunctionManager::MyFunctionManager()
    : FunctionManager()
{}

MyFunctionManager::~MyFunctionManager()
{}


bool MyFunctionManager::initialize(RTC::RTObject_impl &object)
{
% for func_str in function_strs
${func_str}
% endfor

    return true;
}

/* Compile functions class defined. */
% for func in functions
#include <${func.classname}.cpp>
% endfor

