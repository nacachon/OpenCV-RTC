﻿# -*- coding: utf-8 -*-

import os
import os.path
import sys
import traceback
import DefineFileParser
import datetime
import shutil

# OpenCV-RTCのパス名(ツールからの相対)
OPENCV_RTC_PATH                     = '..'

# src/from_definitionフォルダのパス
SRC_FROM_DEFINITION_PATH            = OPENCV_RTC_PATH + '/src/from_definition'

# include/from_definitionフォルダのパス
INC_FROM_DEFINITION_PATH            = OPENCV_RTC_PATH + '/include/OpenCV_RTC/from_definition'

# comp_mockのパス
COMP_MOC_PATH                       = OPENCV_RTC_PATH + '/comp_mock'
COMP_MOC_TEMPLATE_PATH              = 'comp_mock_template'

# テンプレートファイル(ソース)
TEMPLATE_FILE_PATH                  = 'DefineFileParser/template'
MY_FUNCTION_MANAGER_TEMPLATE        = TEMPLATE_FILE_PATH + '/MyFunctionManager_template.cpp'
MY_LOOPBACK_CONDITION_CPP_TEMPLATE  = TEMPLATE_FILE_PATH + '/MyLoopBackCondition_template.cpp'
MY_CONFIG_MANAGER_TEMPLATE          = TEMPLATE_FILE_PATH + '/MyConfigurationManager_template.cpp'
MY_FUNCTION_CPP_TEMPLATE            = TEMPLATE_FILE_PATH + '/MyFunction_template.cpp'

# テンプレートファイル(ヘッダ)
MY_LOOPBACK_CONDITION_H_TEMPLATE    = TEMPLATE_FILE_PATH + '/MyLoopBackCondition_template.h'
MY_FUNCTION_H_TEMPLATE              = TEMPLATE_FILE_PATH + '/MyFunction_template.h'

# 出力ファイルパス(ソース)
MY_FUNCTION_MANAGER_OUTPUT          = SRC_FROM_DEFINITION_PATH + '/MyFunctionManager.cpp'
MY_LOOPBACK_CONDITION_CPP_OUTPUT    = SRC_FROM_DEFINITION_PATH + '/MyLoopBackConditionManager.cpp'
MY_CONFIG_MANAGER_OUTPUT            = SRC_FROM_DEFINITION_PATH + '/MyConfigurationManager.cpp'

# 出力ファイルパス(ヘッダ)
MY_LOOPBACK_CONDITION_H_OUTPUT      = INC_FROM_DEFINITION_PATH + '/MyLoopBackCondition.h'

# 出力ファイルパス(comp_moc)
MY_FUNCTION_CPP_OUTPUT              = COMP_MOC_TEMPLATE_PATH + '/#FUNC_NAME#.cpp'
MY_FUNCTION_H_OUTPUT                = COMP_MOC_TEMPLATE_PATH + '/#FUNC_NAME#.h'

if __name__ == "__main__":
    # コマンドライン引数の個数と内容を取得
    argv = sys.argv
    argc = len(argv)

    if argc != 2:
        print 'Usage: OpenCV-RTC Parser use 3 arguments'
        print ' arg[1] : Input file name'
        quit()

    # 分析するファイルの読込
    try:
        print 'Loading define file : %s'%argv[1]
        f = open( argv[1] )
    except:
        print 'Error: Target file %s is not exist'%argv[1]
        quit()


    # 定義ファイルの分析
    try:
        data = f.read()
        f.close()
        analyze = DefineFileParser.DefineFileAnalyzer(data)
    except:
        print 'Error: Analyze define file %s failed' % argv[1]
        traceback.print_exc()
        quit()

    # 各種テンプレートファイルの読み込み
    try:
        # MyFunctionManagerテンプレートファイルの読込
        f = open( MY_FUNCTION_MANAGER_TEMPLATE )
        myfuncmanager_template = f.read()
        f.close()
    except:
        print 'Error: Template file %s read failed' % MY_FUNCTION_MANAGER_TEMPLATE
        traceback.print_exc()
        quit()

    try:
        # MyLoopbackCondition(ソース)テンプレートファイルの読込
        f = open( MY_LOOPBACK_CONDITION_CPP_TEMPLATE )
        myloopback_cpp_template = f.read()
        f.close()
    except:
        print 'Error: Template file %s read failed' % MY_LOOPBACK_CONDITION_CPP_TEMPLATE
        traceback.print_exc()
        quit()

    try:
        # MyLoopbackCondition(ヘッダ)テンプレートファイルの読込
        f = open( MY_LOOPBACK_CONDITION_H_TEMPLATE )
        myloopback_h_template = f.read()
        f.close()
    except:
        print 'Error: Template file %s read failed' % MY_LOOPBACK_CONDITION_H_TEMPLATE
        traceback.print_exc()
        quit()

    try:
        # MyConfigurationManagerテンプレートファイルの読込
        f = open( MY_CONFIG_MANAGER_TEMPLATE )
        myconfigmanager_template = f.read()
        f.close()
    except:
        print 'Error: Template file %s read failed' % MY_CONFIG_MANAGER_TEMPLATE
        traceback.print_exc()
        quit()

    try:
        # MyFunctionXXX(ソース)テンプレートファイルの読込
        f = open( MY_FUNCTION_CPP_TEMPLATE )
        myfunccpptemplate = f.read()
        f.close()
    except:
        print 'Error: Template file %s read failed' % MY_FUNCTION_CPP_TEMPLATE
        traceback.print_exc()
        quit()

    try:
        # MyFunctionXXX(ヘッダ)テンプレートファイルの読込
        f = open( MY_FUNCTION_H_TEMPLATE )
        myfunchtemplate = f.read()
        f.close()
    except:
        print 'Error: Template file %s read failed' % MY_FUNCTION_H_TEMPLATE
        traceback.print_exc()
        quit()

    # comp_mocフォルダの作成
    if os.path.exists(COMP_MOC_PATH)==False:
        os.mkdir(COMP_MOC_PATH)

    # OUTPUTフォルダの作成
    if os.path.exists(COMP_MOC_TEMPLATE_PATH) == True:
        # 配下のファイルを全削除する
        for (root, dirs, files) in os.walk(COMP_MOC_TEMPLATE_PATH, topdown=False):
            for d in dirs:
                if os.path.islink(os.path.join(root, d)):
                    os.remove(os.path.join(root, d))  # シンボリックリンク
                else:
                    os.rmdir(os.path.join(root, d))  # ディレクトリ
            for f in files:
                os.remove(os.path.join(root, f))  # ファイル
    else:
        os.mkdir(COMP_MOC_TEMPLATE_PATH)

    # from_definitionフォルダの作成
    if os.path.exists(SRC_FROM_DEFINITION_PATH)==False:
        os.makedirs(SRC_FROM_DEFINITION_PATH)
    if os.path.exists(INC_FROM_DEFINITION_PATH)==False:
        os.makedirs(INC_FROM_DEFINITION_PATH)

    # Backupフォルダの作成
    if os.path.exists('backup')==False:
        os.makedirs('backup')

    backupFolder = 'backup/' + datetime.datetime.now().strftime('%Y%m%d%H%M%S')

    #-----------------------------------
    # Backupの実施
    #-----------------------------------
    shutil.copytree(COMP_MOC_PATH,backupFolder)

    #-----------------------------------
    # "MyFunctionManager.cpp"の作成
    #-----------------------------------
    try :
        result = analyze.createMyFunctionManager(myfuncmanager_template)
        # 出力ファイルのオープン
        f = open( MY_FUNCTION_MANAGER_OUTPUT, 'w')
        f.write(result)
        f.close()
        print 'Create result file : %s' % MY_FUNCTION_MANAGER_OUTPUT
    except:
        print 'Error: Target file %s creation failed' % MY_FUNCTION_MANAGER_OUTPUT
        traceback.print_exc()
        quit()

    #-----------------------------------
    # "MyLoopbackCondition.cpp"の作成
    #-----------------------------------
    try :
        result = analyze.createMyLoopbackCondition(myloopback_cpp_template)
        # 出力ファイルのオープン
        f = open( MY_LOOPBACK_CONDITION_CPP_OUTPUT, 'w')
        f.write(result)
        f.close()
        print 'Create result file : %s' % MY_LOOPBACK_CONDITION_CPP_OUTPUT
    except:
        print 'Error: Target file %s creation failed' % MY_LOOPBACK_CONDITION_CPP_OUTPUT
        traceback.print_exc()
        quit()

    #-----------------------------------
    # "MyLoopbackCondition.h"の作成
    #-----------------------------------
    try :
        result = analyze.createMyLoopbackCondition(myloopback_h_template)
        # 出力ファイルのオープン
        f = open( MY_LOOPBACK_CONDITION_H_OUTPUT, 'w')
        f.write(result)
        f.close()
        print 'Create result file : %s' % MY_LOOPBACK_CONDITION_H_OUTPUT
    except:
        print 'Error: Target file %s creation failed' % MY_LOOPBACK_CONDITION_H_OUTPUT
        traceback.print_exc()
        quit()

    #-----------------------------------
    # "MyConfigurationManager.cpp"の作成
    #-----------------------------------
    try :
        result = analyze.createMyConfigurationManager(myconfigmanager_template)
        # 出力ファイルのオープン
        f = open( MY_CONFIG_MANAGER_OUTPUT, 'w')
        f.write(result)
        f.close()
        print 'Create result file : %s' % MY_CONFIG_MANAGER_OUTPUT
    except:
        print 'Error: Target file %s creation failed' % MY_CONFIG_MANAGER_OUTPUT
        traceback.print_exc()
        quit()

    #-----------------------------------
    # ファンクション毎のコンポーネントファイルの作成
    #-----------------------------------
    functions = analyze.getFunctionList()
    for function in functions:
        for author in function['authors']:
            #-----------------------------------
            # "MyFunctionXXX.cpp"の作成
            #-----------------------------------
            try:
                output = MY_FUNCTION_CPP_OUTPUT.replace('#FUNC_NAME#', '%s_%s'%(function['name'],author) )

                result = analyze.createMyFunction(function['name'], author, myfunccpptemplate)

                # 出力ファイルのオープン
                f = open( output, 'w')
                f.write(result)
                f.close()
                print 'Create result file : %s' % output
            except:
                print 'Error: Target file %s creation failed' % output
                traceback.print_exc()
                quit()

            try:
                #-----------------------------------
                # "MyFunctionXXX.h"の作成
                #-----------------------------------
                output = MY_FUNCTION_H_OUTPUT.replace('#FUNC_NAME#', '%s_%s'%(function['name'],author) )

                result = analyze.createMyFunction(function['name'], author, myfunchtemplate)

                # 出力ファイルのオープン
                f = open( output, 'w')
                f.write(result)
                f.close()
                print 'Create result file : %s' % output
            except:
                print 'Error: Target file %s creation failed' % output
                traceback.print_exc()
                quit()
