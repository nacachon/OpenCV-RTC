// This file is created automatically.
#include <calcOpticalFlowFarneback_default.h>

RTC::ReturnCode_t calcOpticalFlowFarneback_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowFarneback_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowFarneback_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowFarneback_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowFarneback_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowFarneback_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowFarneback_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowFarneback_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowFarneback_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowFarneback_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowFarneback_default::onRateChanged()
{
    return RTC::RTC_OK;
}