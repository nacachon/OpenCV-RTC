// This file is created automatically.
#include <Canny_default.h>

RTC::ReturnCode_t Canny_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Canny_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Canny_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Canny_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Canny_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Canny_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Canny_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Canny_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Canny_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Canny_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Canny_default::onRateChanged()
{
    return RTC::RTC_OK;
}