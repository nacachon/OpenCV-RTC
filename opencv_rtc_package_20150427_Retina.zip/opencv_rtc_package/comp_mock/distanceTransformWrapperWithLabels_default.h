#ifndef _distanceTransformWrapperWithLabels_default_H
#define _distanceTransformWrapperWithLabels_default_H

#include <Function.h>

using namespace std;
using namespace cv;

class distanceTransformWrapperWithLabels_default:
  public  Function<void (cv::Mat&,cv::Mat&,cv::Mat&,int,int,int)>
{
public:
    /*!
     * @brief Constructor
     * @param[in] name  PortName
     * @param[in] param 
     */
    distanceTransformWrapperWithLabels_default( 
        RTC::RTObject_impl& obj,
        const std::string& name,
        FuncType func,
        ParameterT<void> p0,
        ParameterT<cv::Mat&> p1,
        ParameterT<cv::Mat&> p2,
        ParameterT<cv::Mat&> p3,
        ParameterT<int> p4,
        ParameterT<int> p5,
        ParameterT<int> p6
        ) : 
        Function<void (cv::Mat&,cv::Mat&,cv::Mat&,int,int,int)>(obj, name, func, p0, p1, p2, p3, p4, p5, p6)
    {};

    virtual RTC::ReturnCode_t onInitialize();
    virtual RTC::ReturnCode_t onStartup();
    virtual RTC::ReturnCode_t onActivated();
    virtual RTC::ReturnCode_t onDeactivated();
    virtual RTC::ReturnCode_t onShutdown();
    virtual RTC::ReturnCode_t onFinalize();
    virtual RTC::ReturnCode_t onAborting();
    virtual RTC::ReturnCode_t onError();
    virtual RTC::ReturnCode_t onReset();
    virtual RTC::ReturnCode_t onStateUpdate();
    virtual RTC::ReturnCode_t onRateChanged();

};

#endif // _distanceTransformWrapperWithLabels_default_H
