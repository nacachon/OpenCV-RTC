// This file is created automatically.
#include <adaptiveThreshold_default.h>

RTC::ReturnCode_t adaptiveThreshold_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t adaptiveThreshold_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t adaptiveThreshold_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t adaptiveThreshold_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t adaptiveThreshold_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t adaptiveThreshold_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t adaptiveThreshold_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t adaptiveThreshold_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t adaptiveThreshold_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t adaptiveThreshold_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t adaptiveThreshold_default::onRateChanged()
{
    return RTC::RTC_OK;
}