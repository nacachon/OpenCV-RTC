// This file is created automatically.
#include <pyrUp_default.h>

RTC::ReturnCode_t pyrUp_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t pyrUp_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t pyrUp_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t pyrUp_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t pyrUp_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t pyrUp_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t pyrUp_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t pyrUp_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t pyrUp_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t pyrUp_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t pyrUp_default::onRateChanged()
{
    return RTC::RTC_OK;
}