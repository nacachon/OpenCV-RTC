#ifndef _imread_default_H
#define _imread_default_H

#include <Function.h>

using namespace std;
using namespace cv;

class imread_default:
  public  Function<cv::Mat (string&,int)>
{
public:
    /*!
     * @brief Constructor
     * @param[in] name  PortName
     * @param[in] param 
     */
    imread_default( 
        RTC::RTObject_impl& obj,
        const std::string& name,
        FuncType func,
        ParameterT<cv::Mat> p0,
        ParameterT<string&> p1,
        ParameterT<int> p2
        ) : 
        Function<cv::Mat (string&,int)>(obj, name, func, p0, p1, p2)
    {};

    virtual RTC::ReturnCode_t onInitialize();
    virtual RTC::ReturnCode_t onStartup();
    virtual RTC::ReturnCode_t onActivated();
    virtual RTC::ReturnCode_t onDeactivated();
    virtual RTC::ReturnCode_t onShutdown();
    virtual RTC::ReturnCode_t onFinalize();
    virtual RTC::ReturnCode_t onAborting();
    virtual RTC::ReturnCode_t onError();
    virtual RTC::ReturnCode_t onReset();
    virtual RTC::ReturnCode_t onStateUpdate();
    virtual RTC::ReturnCode_t onRateChanged();

};

#endif // _imread_default_H
