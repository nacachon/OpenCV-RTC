// This file is created automatically.
#include <imread_default.h>

RTC::ReturnCode_t imread_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t imread_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t imread_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t imread_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t imread_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t imread_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t imread_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t imread_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t imread_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t imread_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t imread_default::onRateChanged()
{
    return RTC::RTC_OK;
}