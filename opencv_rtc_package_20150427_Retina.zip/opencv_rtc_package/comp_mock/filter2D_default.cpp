// This file is created automatically.
#include <filter2D_default.h>

RTC::ReturnCode_t filter2D_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t filter2D_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t filter2D_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t filter2D_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t filter2D_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t filter2D_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t filter2D_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t filter2D_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t filter2D_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t filter2D_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t filter2D_default::onRateChanged()
{
    return RTC::RTC_OK;
}