// This file is created automatically.
#include <show_image_default.h>

RTC::ReturnCode_t show_image_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t show_image_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t show_image_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t show_image_default::onDeactivated()
{
    SDOPackage::Configuration_var config = object.get_configuration();
    SDOPackage::ConfigurationSet_var configset = config->get_active_configuration_set();

    std::string winname = NVUtil::toString(configset->configuration_data, "win_name" );

    cv::destroyWindow(winname);

    return RTC::RTC_OK;
}

RTC::ReturnCode_t show_image_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t show_image_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t show_image_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t show_image_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t show_image_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t show_image_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t show_image_default::onRateChanged()
{
    return RTC::RTC_OK;
}