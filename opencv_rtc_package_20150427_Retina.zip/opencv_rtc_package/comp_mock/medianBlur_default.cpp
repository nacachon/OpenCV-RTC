// This file is created automatically.
#include <medianBlur_default.h>

RTC::ReturnCode_t medianBlur_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t medianBlur_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t medianBlur_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t medianBlur_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t medianBlur_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t medianBlur_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t medianBlur_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t medianBlur_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t medianBlur_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t medianBlur_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t medianBlur_default::onRateChanged()
{
    return RTC::RTC_OK;
}