// This file is created automatically.
#include <calcOpticalFlowPyrLK_default.h>

RTC::ReturnCode_t calcOpticalFlowPyrLK_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowPyrLK_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowPyrLK_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowPyrLK_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowPyrLK_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowPyrLK_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowPyrLK_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowPyrLK_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowPyrLK_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowPyrLK_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t calcOpticalFlowPyrLK_default::onRateChanged()
{
    return RTC::RTC_OK;
}