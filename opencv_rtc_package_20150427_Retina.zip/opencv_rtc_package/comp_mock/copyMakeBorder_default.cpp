// This file is created automatically.
#include <copyMakeBorder_default.h>

RTC::ReturnCode_t copyMakeBorder_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t copyMakeBorder_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t copyMakeBorder_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t copyMakeBorder_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t copyMakeBorder_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t copyMakeBorder_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t copyMakeBorder_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t copyMakeBorder_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t copyMakeBorder_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t copyMakeBorder_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t copyMakeBorder_default::onRateChanged()
{
    return RTC::RTC_OK;
}