// This file is created automatically.
#include <distanceTransformWrapper_default.h>

RTC::ReturnCode_t distanceTransformWrapper_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t distanceTransformWrapper_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t distanceTransformWrapper_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t distanceTransformWrapper_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t distanceTransformWrapper_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t distanceTransformWrapper_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t distanceTransformWrapper_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t distanceTransformWrapper_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t distanceTransformWrapper_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t distanceTransformWrapper_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t distanceTransformWrapper_default::onRateChanged()
{
    return RTC::RTC_OK;
}