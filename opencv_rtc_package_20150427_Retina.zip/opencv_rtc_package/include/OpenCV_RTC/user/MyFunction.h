#ifndef MY_FUNCTION_H
#define MY_FUNCTION_H

#include <vector>
#include <string>
#include <opencv2/opencv.hpp>

/* ���̑� */
void load_image( const std::string& file, cv::Mat& dst );
void test_vector( std::vector<cv::Point2f>& dst );
void test_matrix( cv::Mat& dst );
void test_vmatrix_in( std::vector<cv::Mat>& vmat );
void test_vmatrix_out( std::vector<cv::Mat>& vmat );


#endif //MY_FUNCTION_H
