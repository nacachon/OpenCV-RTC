// This file is created automatically.

#ifndef _MYLOOPBACKCONDITIONMANAGER_H_
#define _MYLOOPBACKCONDITIONMANAGER_H_

#include "LoopBackCondition.h"

class LoopBackConditionBilateralFilter : public LoopBackCondition
{
public:
    LoopBackConditionBilateralFilter(RTC::RTObject_impl &obj)
        : LoopBackCondition( obj ){};
    bool useInitialData( const std::string & portname );
    void getInitialData( const std::string & portname );
};

class LoopBackConditionBlur : public LoopBackCondition
{
public:
    LoopBackConditionBlur(RTC::RTObject_impl &obj)
        : LoopBackCondition( obj ){};
    bool useInitialData( const std::string & portname );
    void getInitialData( const std::string & portname );
};

class LoopBackConditionShow_image : public LoopBackCondition
{
public:
    LoopBackConditionShow_image(RTC::RTObject_impl &obj)
        : LoopBackCondition( obj ){};
    bool useInitialData( const std::string & portname );
    void getInitialData( const std::string & portname );
};

class LoopBackConditionImread : public LoopBackCondition
{
public:
    LoopBackConditionImread(RTC::RTObject_impl &obj)
        : LoopBackCondition( obj ){};
    bool useInitialData( const std::string & portname );
    void getInitialData( const std::string & portname );
};

#endif // _MYLOOPBACKCONDITIONMANAGER_H_