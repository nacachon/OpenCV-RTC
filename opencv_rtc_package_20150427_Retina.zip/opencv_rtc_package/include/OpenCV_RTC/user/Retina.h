#ifndef _RETINA_
#define _RETINA_

#include <opencv2/opencv.hpp>

void cvRetina(cv::Mat& src,	cv::Mat& magno,cv::Mat& parvo, int log_sampling);

#endif  // _RETINA_