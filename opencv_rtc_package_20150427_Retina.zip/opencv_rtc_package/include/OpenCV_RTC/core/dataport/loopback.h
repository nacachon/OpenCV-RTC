
#ifndef _LOOPBACK_H_
#define _LOOPBACK_H_

#include <vector>

#define USE_LOOPBACK				std::vector<InPortBase *> __inports;  bool useInitialData( const std::string &inport_name );   void getInitialData( const std::string &inport_name );

#define REGIST_INPORT(inport)		__inports.push_back( &inport )

#define IS_NEW(port)				(useInitialData(port.getName()) ? true : port.isNew())

#define ALL_READ()					{																\
										for ( int i = 0; i< __inports.size(); i++ ) {				\
											if ( useInitialData( __inports[i]->getName() ) ) {		\
												getInitialData( __inports[i]->getName() );			\
											} else {												\
												__inports[i]->read();								\
											}														\
										}															\
									}



#endif // _LOOPBACK_H_
