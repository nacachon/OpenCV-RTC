#pragma once

#include <boost/shared_ptr.hpp>
#include <rtm/RTObject.h>
#include "Parameter.h"

class DataPortFactory
{
public:
	static boost::shared_ptr<RTC::InPortBase>  createInPort( ParameterBase& val );
	static boost::shared_ptr<RTC::OutPortBase> createOutPort( ParameterBase& val );

private:
	DataPortFactory();
	virtual ~DataPortFactory();
};

