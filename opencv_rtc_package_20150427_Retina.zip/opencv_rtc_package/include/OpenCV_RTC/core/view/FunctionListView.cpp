#include "FunctionListViewPrivate.h"
#include "FunctionListView.h"

#include <assert.h>
#include <string>
#include <vector>
#include <gcroot.h>


void FunctionListView_createForm( std::vector<std::string>& func_list )
{
	// Factory���擾����B
	gcroot<OpenCV_RTCComp::FunctionListView^> listView = gcnew OpenCV_RTCComp::FunctionListView();
	listView->registerFunctionList( func_list );
	//listView->ShowDialog();
	OpenCV_RTCComp::Application::Run( listView );
}


static void (*save_callback_)(const std::string&)   = NULL;
static void (*load_callback_)(const std::string&)   = NULL;
static void (*create_callback_)(const std::string&) = NULL;

void FunctionListView_setCallbacks( 
	void (*save_callback)(const std::string&), 
	void (*create_callback)(const std::string&),
	void (*load_callback)(const std::string&)
	)
{
	// �����`�F�b�N
	assert( save_callback != NULL );
	assert( create_callback != NULL );
	assert( load_callback != NULL );

	// �R�[���o�b�N�֐��̐ݒ�
	save_callback_ = save_callback;
	load_callback_ = load_callback;
	create_callback_ = create_callback;
}


void FunctionListView_createComponent( const std::string& func_name )
{
	assert( create_callback_ != NULL );
	create_callback_( func_name );
}

void FunctionListView_saveComponentState( const std::string& file_name )
{
	assert( save_callback_ != NULL );
	save_callback_( file_name );
}

void FunctionListView_loadComponentState( const std::string& file_name )
{
	assert( load_callback_ != NULL );
	load_callback_( file_name );
}