#ifndef FUNCTION_H
#define FUNCTION_H

#define BOOST_FUNCTION_MAX_ARGS 20

#include <iostream>
#include <string>
#include <vector>
#include <boost/function.hpp>

#include <rtm/RTObject.h>
#include "Parameter.h"

/*!
 * @class FunctionBase�N���X
 * @brief �֐����N���X
 */
class FunctionBase
{
protected:
	/*!
	 * @brief �p�����[�^�z��^�̒�`
	 */
	typedef std::vector<ParameterBase*> ParamArray;
	
	/*!
	 * @brief �p�����[�^�ꗗ
	 */
	ParamArray    params_;
	
	
	/*!
	 * @brief �֐���
	 */
	std::string   name_;

	/*!
	 * @brief T�^��Parameter�N���X��o�^����
	 * @param[in] �p�����[�^�N���X�ւ̃|�C���^
	 */
	template<class T>
	void registerParameter( Parameter<T>* param ) 
	{
		// Parameter��void�^�f�Ȃ��̂Ȃ�΁A�ǉ����s��
		params_.push_back( param );
	}

	/*!
	 * @brief Void�^Parameter�o�^��������邽�߂̊֐�
	 * @param[in] VoidParameter�ւ̃|�C���^
	 */
	void registerParameter( VoidParameter* param ) 
	{
		// DO NOTHING
	}

public:
	/*!
	 * @brief �R���X�g���N�^
	 * @param[in] name �֐���
	 */
	FunctionBase( const std::string& name )
		: name_(name) {}
	
	/*!
	 * @brief �f�X�g���N�^
	 */
	virtual ~FunctionBase() {}
	
	/*!
	 * @brief �֐������擾����
	 * @return �֐���
	 */
	std::string getName() const { return name_; }
	
	/*!
	 * @brief �p�����[�^�ꗗ���擾����
	 * @return �p�����[�^�ꗗ
	 */
	ParamArray  getParamArray() { return params_; }
	
	/*!
	 * @brief �p�����[�^���擾����
	 * @return �p�����[�^
	 */
	ParameterBase *getParam( const std::string &paramName ) {

        ParameterBase *retParam = NULL;

        ParamArray::iterator param;
        for ( param = params_.begin(); param != params_.end(); ++param ) {
            if ( (*param)->getName() == paramName ) {
                retParam = (*param);
            }
        }

        return retParam;
    }
	
	virtual void onExecute() = 0;
	virtual RTC::ReturnCode_t onInitialize() = 0;
	virtual RTC::ReturnCode_t onStartup() = 0;
	virtual RTC::ReturnCode_t onActivated() = 0;
	virtual RTC::ReturnCode_t onDeactivated() = 0;
	virtual RTC::ReturnCode_t onShutdown() = 0;
	virtual RTC::ReturnCode_t onFinalize() = 0;
	virtual RTC::ReturnCode_t onAborting() = 0;
	virtual RTC::ReturnCode_t onError() = 0;
	virtual RTC::ReturnCode_t onReset() = 0;
	virtual RTC::ReturnCode_t onStateUpdate() = 0;
	virtual RTC::ReturnCode_t onRateChanged() = 0;

};


#define FUNC_TYPENAME0	
#define FUNC_TYPENAME1	typename T0
#define FUNC_TYPENAME2	FUNC_TYPENAME1, typename T1
#define FUNC_TYPENAME3	FUNC_TYPENAME2, typename T2
#define FUNC_TYPENAME4	FUNC_TYPENAME3, typename T3
#define FUNC_TYPENAME5	FUNC_TYPENAME4, typename T4
#define FUNC_TYPENAME6	FUNC_TYPENAME5, typename T5
#define FUNC_TYPENAME7	FUNC_TYPENAME6, typename T6
#define FUNC_TYPENAME8	FUNC_TYPENAME7, typename T7
#define FUNC_TYPENAME9	FUNC_TYPENAME8, typename T8
#define FUNC_TYPENAME10	FUNC_TYPENAME9, typename T9
#define FUNC_TYPENAME11	FUNC_TYPENAME10, typename T10
#define FUNC_TYPENAME12	FUNC_TYPENAME11, typename T11
#define FUNC_TYPENAME13	FUNC_TYPENAME12, typename T12
#define FUNC_TYPENAME14	FUNC_TYPENAME13, typename T13
#define FUNC_TYPENAME15	FUNC_TYPENAME14, typename T14

#define FUNC_TEMPLATE0	
#define FUNC_TEMPLATE1	T0
#define FUNC_TEMPLATE2	FUNC_TEMPLATE1, T1
#define FUNC_TEMPLATE3	FUNC_TEMPLATE2, T2
#define FUNC_TEMPLATE4	FUNC_TEMPLATE3, T3
#define FUNC_TEMPLATE5	FUNC_TEMPLATE4, T4
#define FUNC_TEMPLATE6	FUNC_TEMPLATE5, T5
#define FUNC_TEMPLATE7	FUNC_TEMPLATE6, T6
#define FUNC_TEMPLATE8	FUNC_TEMPLATE7, T7
#define FUNC_TEMPLATE9	FUNC_TEMPLATE8, T8
#define FUNC_TEMPLATE10	FUNC_TEMPLATE9, T9
#define FUNC_TEMPLATE11	FUNC_TEMPLATE10, T10
#define FUNC_TEMPLATE12	FUNC_TEMPLATE11, T11
#define FUNC_TEMPLATE13	FUNC_TEMPLATE12, T12
#define FUNC_TEMPLATE14	FUNC_TEMPLATE13, T13
#define FUNC_TEMPLATE15	FUNC_TEMPLATE14, T14

#define PARAM(n)		ParameterT<T##n> param##n
#define FUNC_PARAM0     PARAM(R);
#define FUNC_PARAM1		FUNC_PARAM0 PARAM(0);
#define FUNC_PARAM2		FUNC_PARAM1 PARAM(1);
#define FUNC_PARAM3		FUNC_PARAM2 PARAM(2);
#define FUNC_PARAM4		FUNC_PARAM3 PARAM(3);
#define FUNC_PARAM5		FUNC_PARAM4 PARAM(4);
#define FUNC_PARAM6		FUNC_PARAM5 PARAM(5);
#define FUNC_PARAM7		FUNC_PARAM6 PARAM(6);
#define FUNC_PARAM8		FUNC_PARAM7 PARAM(7);
#define FUNC_PARAM9		FUNC_PARAM8 PARAM(8);
#define FUNC_PARAM10	FUNC_PARAM9 PARAM(9);
#define FUNC_PARAM11	FUNC_PARAM10 PARAM(10);
#define FUNC_PARAM12	FUNC_PARAM11 PARAM(11);
#define FUNC_PARAM13	FUNC_PARAM12 PARAM(12);
#define FUNC_PARAM14	FUNC_PARAM13 PARAM(13);
#define FUNC_PARAM15	FUNC_PARAM14 PARAM(14);

#define ARG(n)			const ParameterT<T##n>& p##n
#define FUNC_ARG0		ARG(R)
#define FUNC_ARG1		FUNC_ARG0, ARG(0)
#define FUNC_ARG2		FUNC_ARG1, ARG(1)
#define FUNC_ARG3		FUNC_ARG2, ARG(2)
#define FUNC_ARG4		FUNC_ARG3, ARG(3)
#define FUNC_ARG5		FUNC_ARG4, ARG(4)
#define FUNC_ARG6		FUNC_ARG5, ARG(5)
#define FUNC_ARG7		FUNC_ARG6, ARG(6)
#define FUNC_ARG8		FUNC_ARG7, ARG(7)
#define FUNC_ARG9		FUNC_ARG8, ARG(8)
#define FUNC_ARG10		FUNC_ARG9, ARG(9)
#define FUNC_ARG11		FUNC_ARG10, ARG(10)
#define FUNC_ARG12		FUNC_ARG11, ARG(11)
#define FUNC_ARG13		FUNC_ARG12, ARG(12)
#define FUNC_ARG14		FUNC_ARG13, ARG(13)
#define FUNC_ARG15		FUNC_ARG14, ARG(14)

#define INIT(n)			param##n(p##n)
#define FUNC_INIT0		INIT(R)
#define FUNC_INIT1		FUNC_INIT0, INIT(0)
#define FUNC_INIT2		FUNC_INIT1, INIT(1)
#define FUNC_INIT3		FUNC_INIT2, INIT(2)
#define FUNC_INIT4		FUNC_INIT3, INIT(3)
#define FUNC_INIT5		FUNC_INIT4, INIT(4)
#define FUNC_INIT6		FUNC_INIT5, INIT(5)
#define FUNC_INIT7		FUNC_INIT6, INIT(6)
#define FUNC_INIT8		FUNC_INIT7, INIT(7)
#define FUNC_INIT9		FUNC_INIT8, INIT(8)
#define FUNC_INIT10		FUNC_INIT9, INIT(9)
#define FUNC_INIT11		FUNC_INIT10, INIT(10)
#define FUNC_INIT12		FUNC_INIT11, INIT(11)
#define FUNC_INIT13		FUNC_INIT12, INIT(12)
#define FUNC_INIT14		FUNC_INIT13, INIT(13)
#define FUNC_INIT15		FUNC_INIT14, INIT(14)

#define FUNC_PUSH(n)	registerParameter(&param##n);
#define FUNC_PUSH0		FUNC_PUSH(R)
#define FUNC_PUSH1		FUNC_PUSH0 FUNC_PUSH(0)
#define FUNC_PUSH2		FUNC_PUSH1 FUNC_PUSH(1)
#define FUNC_PUSH3		FUNC_PUSH2 FUNC_PUSH(2)
#define FUNC_PUSH4		FUNC_PUSH3 FUNC_PUSH(3)
#define FUNC_PUSH5		FUNC_PUSH4 FUNC_PUSH(4)
#define FUNC_PUSH6		FUNC_PUSH5 FUNC_PUSH(5)
#define FUNC_PUSH7		FUNC_PUSH6 FUNC_PUSH(6)
#define FUNC_PUSH8		FUNC_PUSH7 FUNC_PUSH(7)
#define FUNC_PUSH9		FUNC_PUSH8 FUNC_PUSH(8)
#define FUNC_PUSH10		FUNC_PUSH9 FUNC_PUSH(9)
#define FUNC_PUSH11		FUNC_PUSH10 FUNC_PUSH(10)
#define FUNC_PUSH12		FUNC_PUSH11 FUNC_PUSH(11)
#define FUNC_PUSH13		FUNC_PUSH12 FUNC_PUSH(12)
#define FUNC_PUSH14		FUNC_PUSH13 FUNC_PUSH(13)
#define FUNC_PUSH15		FUNC_PUSH14 FUNC_PUSH(14)

#define FUNC_CONSTRUCT(n)	p##n
#define FUNC_CONSTRUCT0		FUNC_CONSTRUCT(R)
#define FUNC_CONSTRUCT1		FUNC_CONSTRUCT0, FUNC_CONSTRUCT(0)
#define FUNC_CONSTRUCT2		FUNC_CONSTRUCT1, FUNC_CONSTRUCT(1)
#define FUNC_CONSTRUCT3		FUNC_CONSTRUCT2, FUNC_CONSTRUCT(2)
#define FUNC_CONSTRUCT4		FUNC_CONSTRUCT3, FUNC_CONSTRUCT(3)
#define FUNC_CONSTRUCT5		FUNC_CONSTRUCT4, FUNC_CONSTRUCT(4)
#define FUNC_CONSTRUCT6		FUNC_CONSTRUCT5, FUNC_CONSTRUCT(5)
#define FUNC_CONSTRUCT7		FUNC_CONSTRUCT6, FUNC_CONSTRUCT(6)
#define FUNC_CONSTRUCT8		FUNC_CONSTRUCT7, FUNC_CONSTRUCT(7)
#define FUNC_CONSTRUCT9		FUNC_CONSTRUCT8, FUNC_CONSTRUCT(8)
#define FUNC_CONSTRUCT10	FUNC_CONSTRUCT9, FUNC_CONSTRUCT(9)
#define FUNC_CONSTRUCT11	FUNC_CONSTRUCT10, FUNC_CONSTRUCT(10)
#define FUNC_CONSTRUCT12	FUNC_CONSTRUCT11, FUNC_CONSTRUCT(11)
#define FUNC_CONSTRUCT13	FUNC_CONSTRUCT12, FUNC_CONSTRUCT(12)
#define FUNC_CONSTRUCT14	FUNC_CONSTRUCT13, FUNC_CONSTRUCT(13)
#define FUNC_CONSTRUCT15	FUNC_CONSTRUCT14, FUNC_CONSTRUCT(14)

#define FUNC_VALUE(n)	param##n.getValue()
#define FUNC_VALUE0
#define FUNC_VALUE1		FUNC_VALUE(0)
#define FUNC_VALUE2		FUNC_VALUE1, FUNC_VALUE(1)
#define FUNC_VALUE3		FUNC_VALUE2, FUNC_VALUE(2)
#define FUNC_VALUE4		FUNC_VALUE3, FUNC_VALUE(3)
#define FUNC_VALUE5		FUNC_VALUE4, FUNC_VALUE(4)
#define FUNC_VALUE6		FUNC_VALUE5, FUNC_VALUE(5)
#define FUNC_VALUE7		FUNC_VALUE6, FUNC_VALUE(6)
#define FUNC_VALUE8		FUNC_VALUE7, FUNC_VALUE(7)
#define FUNC_VALUE9		FUNC_VALUE8, FUNC_VALUE(8)
#define FUNC_VALUE10	FUNC_VALUE9, FUNC_VALUE(9)
#define FUNC_VALUE11	FUNC_VALUE10, FUNC_VALUE(10)
#define FUNC_VALUE12	FUNC_VALUE11, FUNC_VALUE(11)
#define FUNC_VALUE13	FUNC_VALUE12, FUNC_VALUE(12)
#define FUNC_VALUE14	FUNC_VALUE13, FUNC_VALUE(13)
#define FUNC_VALUE15	FUNC_VALUE14, FUNC_VALUE(14)


template<class T>
class Function;

#define FUNCTION(n)																	\
template<typename TR, FUNC_TYPENAME##n>												\
class FunctionT##n : public FunctionBase											\
{																					\
public:																				\
	typedef boost::function<TR (FUNC_TEMPLATE##n)> FuncType;						\
																					\
protected:																			\
	RTC::RTObject_impl& object;														\
	FuncType function;																\
	FUNC_PARAM##n;																	\
																					\
public:																				\
	FunctionT##n( RTC::RTObject_impl& obj, const std::string& name,					\
					FuncType func, FUNC_ARG##n )									\
	: object(obj), FunctionBase(name), function(func), FUNC_INIT##n					\
	{																				\
		FUNC_PUSH##n																\
	}																				\
																					\
	virtual void onExecute() {														\
		onExecute_( paramR );														\
	}																				\
																					\
																					\
protected:																			\
	template<typename T>															\
	void onExecute_( Parameter<T>& param ) {										\
		T& val = param.getValue();													\
		val = function( FUNC_VALUE##n );											\
	}																				\
																					\
	void onExecute_( VoidParameter& param ) {										\
		function( FUNC_VALUE##n );													\
	}																				\
};																					\
																					\
																					\
template<typename TR, FUNC_TYPENAME##n>												\
class Function<TR (FUNC_TEMPLATE##n)> : public FunctionT##n<TR,FUNC_TEMPLATE##n> {	\
public:																				\
	Function( RTC::RTObject_impl& obj, const std::string& name, FuncType func, FUNC_ARG##n )	\
	: FunctionT##n<TR,FUNC_TEMPLATE##n>( obj, name, func, FUNC_CONSTRUCT##n ) {}	\
																					\
};

FUNCTION(1)
FUNCTION(2)
FUNCTION(3)
FUNCTION(4)
FUNCTION(5)
FUNCTION(6)
FUNCTION(7)
FUNCTION(8)
FUNCTION(9)
FUNCTION(10)
FUNCTION(11)
FUNCTION(12)
FUNCTION(13)
FUNCTION(14)
FUNCTION(15)


#undef FUNCTION

#undef FUNC_TYPENAME0	
#undef FUNC_TYPENAME1
#undef FUNC_TYPENAME2
#undef FUNC_TYPENAME3
#undef FUNC_TYPENAME4
#undef FUNC_TYPENAME5
#undef FUNC_TYPENAME6
#undef FUNC_TYPENAME7
#undef FUNC_TYPENAME8
#undef FUNC_TYPENAME9
#undef FUNC_TYPENAME10
#undef FUNC_TYPENAME11
#undef FUNC_TYPENAME12
#undef FUNC_TYPENAME13
#undef FUNC_TYPENAME14
#undef FUNC_TYPENAME15

#undef FUNC_TEMPLATE0	
#undef FUNC_TEMPLATE1
#undef FUNC_TEMPLATE2
#undef FUNC_TEMPLATE3
#undef FUNC_TEMPLATE4
#undef FUNC_TEMPLATE5
#undef FUNC_TEMPLATE6
#undef FUNC_TEMPLATE7
#undef FUNC_TEMPLATE8
#undef FUNC_TEMPLATE9
#undef FUNC_TEMPLATE10
#undef FUNC_TEMPLATE11
#undef FUNC_TEMPLATE12
#undef FUNC_TEMPLATE13
#undef FUNC_TEMPLATE14
#undef FUNC_TEMPLATE15

#undef PARAM
#undef FUNC_PARAM0
#undef FUNC_PARAM1
#undef FUNC_PARAM2
#undef FUNC_PARAM3
#undef FUNC_PARAM4
#undef FUNC_PARAM5
#undef FUNC_PARAM6
#undef FUNC_PARAM7
#undef FUNC_PARAM8
#undef FUNC_PARAM9
#undef FUNC_PARAM10
#undef FUNC_PARAM11
#undef FUNC_PARAM12
#undef FUNC_PARAM13
#undef FUNC_PARAM14
#undef FUNC_PARAM15

#undef ARG
#undef FUNC_ARG0
#undef FUNC_ARG1
#undef FUNC_ARG2
#undef FUNC_ARG3
#undef FUNC_ARG4
#undef FUNC_ARG5
#undef FUNC_ARG6
#undef FUNC_ARG7
#undef FUNC_ARG8
#undef FUNC_ARG9
#undef FUNC_ARG10
#undef FUNC_ARG11
#undef FUNC_ARG12
#undef FUNC_ARG13
#undef FUNC_ARG14
#undef FUNC_ARG15

#undef INIT
#undef FUNC_INIT0
#undef FUNC_INIT1
#undef FUNC_INIT2
#undef FUNC_INIT3
#undef FUNC_INIT4
#undef FUNC_INIT5
#undef FUNC_INIT6
#undef FUNC_INIT7
#undef FUNC_INIT8
#undef FUNC_INIT9
#undef FUNC_INIT10
#undef FUNC_INIT11
#undef FUNC_INIT12
#undef FUNC_INIT13
#undef FUNC_INIT14
#undef FUNC_INIT15

#undef FUNC_PUSH
#undef FUNC_PUSH0
#undef FUNC_PUSH1
#undef FUNC_PUSH2
#undef FUNC_PUSH3
#undef FUNC_PUSH4
#undef FUNC_PUSH5
#undef FUNC_PUSH6
#undef FUNC_PUSH7
#undef FUNC_PUSH8
#undef FUNC_PUSH9
#undef FUNC_PUSH10
#undef FUNC_PUSH11
#undef FUNC_PUSH12
#undef FUNC_PUSH13
#undef FUNC_PUSH14
#undef FUNC_PUSH15

#undef FUNC_VALUE
#undef FUNC_VALUE0
#undef FUNC_VALUE1
#undef FUNC_VALUE2
#undef FUNC_VALUE3
#undef FUNC_VALUE4
#undef FUNC_VALUE5
#undef FUNC_VALUE6
#undef FUNC_VALUE7
#undef FUNC_VALUE8
#undef FUNC_VALUE9
#undef FUNC_VALUE10
#undef FUNC_VALUE11
#undef FUNC_VALUE12
#undef FUNC_VALUE13
#undef FUNC_VALUE14
#undef FUNC_VALUE15


#endif //FUNCTION_H
