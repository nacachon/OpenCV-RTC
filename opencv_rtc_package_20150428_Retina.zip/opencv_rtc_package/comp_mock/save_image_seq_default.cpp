// This file is created automatically.
#include <save_image_seq_default.h>

RTC::ReturnCode_t save_image_seq_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t save_image_seq_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t save_image_seq_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t save_image_seq_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t save_image_seq_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t save_image_seq_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t save_image_seq_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t save_image_seq_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t save_image_seq_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t save_image_seq_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t save_image_seq_default::onRateChanged()
{
    return RTC::RTC_OK;
}