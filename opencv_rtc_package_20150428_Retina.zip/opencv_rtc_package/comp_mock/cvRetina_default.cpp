// This file is created automatically.
#include <cvRetina_default.h>

RTC::ReturnCode_t cvRetina_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cvRetina_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cvRetina_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cvRetina_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cvRetina_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cvRetina_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cvRetina_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cvRetina_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cvRetina_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cvRetina_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cvRetina_default::onRateChanged()
{
    return RTC::RTC_OK;
}