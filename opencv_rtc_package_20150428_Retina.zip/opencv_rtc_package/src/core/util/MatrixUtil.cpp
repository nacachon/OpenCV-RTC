#include "MatrixUtil.h"

#include <iostream>
#include <fstream>
#include <sstream>

/*!
 * @brief �w�肵���t�@�C�����s������擾����
 * @param[in]  file_name �s���ǂݍ��ރt�@�C����
 * @param[out] mat       �o�͍s��
 * @return          �ǂݍ��ݔ���
*/
bool MatrixUtil::loadMatrix( const std::string& file_name, cv::Mat& mat )
{
	CvFileStorage* storage = cvOpenFileStorage( file_name.c_str(), 0, CV_STORAGE_READ );
	
	if ( storage != NULL ) {
		CvFileNode *node = cvGetFileNodeByName( storage, NULL, "matrix" );
		if ( node != NULL ) {
			CvMat *read = (CvMat*)cvRead( storage, node, NULL );
			mat = cv::Mat( read, true );
			return true;
		}
	}

	return false;
}


/*!
 * @brief �w�肵���t�@�C���ɍs�����ۑ�����
 * @param[in] file_name �s���ۑ�����t�@�C����
 * @param[in] mat       �ۑ�����s��
 * @return              ��������
 */
bool MatrixUtil::saveMatrix( const std::string& file_name, const cv::Mat& mat )
{
	cv::FileStorage storage(file_name, cv::FileStorage::WRITE );
	if ( storage.isOpened() ) {
		storage << "matrix" << mat;
	}
	return true;
}

/*!
 * @brief �w�肵���t�@�C�����s������擾����
 * @param[in] file_name �s���ǂݍ��ރt�@�C����
 * @param[out] mat       �o�͍s��
 * @return          �ǂݍ��ݔ���
 */
bool MatrixUtil::loadMatrixVec( const std::string& file_name, std::vector<cv::Mat>& mats )
{
	/* open file storage */
    cv::FileStorage   cvfs( file_name, cv::FileStorage::READ);

	/* write data to file */
    if ( cvfs.isOpened() ) {

        cv::FileNode node(cvfs.fs, NULL); // Get Top Node
        cv::FileNode arraynode = node["mat_array"];
        mats.resize(arraynode.size());
        for(int i=0;i<arraynode.size();i++){
            cv::read(arraynode[i], mats[i]);
        }
    }

	return true;
}


/*!
 * @brief �w�肵���t�@�C���ɍs�����ۑ�����
 * @param[in] file_name �s���ۑ�����t�@�C����
 * @param[in] mat       �ۑ�����s��
 * @return              ��������
 */
bool MatrixUtil::saveMatrixVec( const std::string& file_name, const std::vector<cv::Mat>& mats )
{
    /* open file storage */
    cv::FileStorage cvfs( file_name, cv::FileStorage::WRITE );

    /* write data to file */
    if ( cvfs.isOpened() ) {
        cv::WriteStructContext ws(cvfs, "mat_array", CV_NODE_SEQ);    // create node

		for( int i=0; i<mats.size(); i++ ) {
            cv::write( cvfs, "", mats[i] );
		}
    }

	return true;
}


bool MatrixUtil::loadPoint2fVec( const std::string& file_name, std::vector<cv::Point2f>& points )
{
    bool ret = false;

    std::ifstream ifs( file_name );
    if ( !ifs ) {
        ret = false;
    } else {
        ret = true;
    }

    if ( ret ) {

        points.resize(0);

        std::string line;
        while( getline( ifs, line ) ){

            if ( line[0]=='#' ){
                /* �R�����g�s�̂��߁A���� */
            } else {
                std::vector<std::string> elements;
                /* Point2f�̗v�f(�_�u���N�H�[�e�[�V�����ň͂܂ꂽ1�g�̐���)�𒊏o���� */
                
                int i=0;
                int i_begin;

                while(true) {
                    /* �I�[�ɓ��B�����烋�[�v�I�� */
                    if( i == line.size() ) {
                        break;
                    } else {
                        if (i !=  0 ) {
                            if ( line[i] == ',' ) {
                                i++;
                            }else{
                                throw new std::exception();
                            }
                        }
                    }

                    i_begin = i;

                    /* �v�f�̐擪��"�̂͂� */
                    if (line[i] != '"') {
                        throw new std::exception();
                    }
                    i++;

                    while(true) {
                        /* �I�[�ɓ��B������t�H�[�}�b�g�G���[ */
                        if( i == line.size() ) throw new std::exception();

                        if (line[i]=='"'){
                            elements.push_back(line.substr(i_begin,(i-i_begin+1)));
                            /*  */
                            i++;
                            break;
                        } else {
                            i++;
                        }
                    }
                }

                for ( std::vector<std::string>::iterator it=elements.begin();
                    it!=elements.end(); ++it ) {

                    std::string x,y;
                    std::istringstream stream( it->substr(1,(it->size()-2)) );
                    if (getline(stream,x,',')) {
                        if (getline(stream,y)) {
                            cv::Point2f point;
							point.x = atof(x.c_str());
                            std::cout << x << std::endl;
                            point.y = atof(y.c_str());
                            points.push_back(point);
                        }
                    }
                }
            }
	    }
    }

    return ret;
}

bool MatrixUtil::loadUcharVec( const std::string& file_name, std::vector<uchar>& uchars )
{
    bool ret = false;

    std::ifstream ifs( file_name );
    if ( !ifs ) {
        ret = false;
    } else {
        ret = true;
    }

    if ( ret ) {
        uchars.resize(0);

        std::string line;
        while( getline( ifs, line ) ){
            long tmp;
            std::string element;
            if ( line[0]=='#' ){
                /* �R�����g�s�̂��߁A���� */
            } else {
                std::istringstream stream( line );
                while ( getline( stream, element, ',') ) {
                    std::stringstream ss;
                    ss << element;
                    ss >> tmp;
                    if ( (tmp > 0) && (tmp < UCHAR_MAX) ) {
                        uchars.push_back((uchar)tmp);
                    } else {
                        throw new std::exception();
                    }
                }
            }
	    }
    }

    return ret;
}

bool MatrixUtil::loadFloatVec( const std::string& file_name, std::vector<float>& floats )
{
    bool ret = false;

    std::ifstream ifs( file_name );
    if ( !ifs ) {
        ret = false;
    } else {
        ret = true;
    }

    if ( ret ) {
        floats.resize(0);

        std::string line;
        while( getline( ifs, line ) ){
            double tmp;
            std::string element;
            if ( line[0]=='#' ){
                /* �R�����g�s�̂��߁A���� */
            } else {
                std::istringstream stream( line );
                while ( getline( stream, element, ',') ) {
                    tmp = atof(element.c_str());
                    floats.push_back((float)tmp);
                }
            }
	    }
    }

    return ret;
}

long MatrixUtil::getMatrixVecLength(const std::string &file)
{
	std::vector<cv::Mat> mats;
	loadMatrixVec(file,mats);

	return mats.size();
}

long MatrixUtil::getPoint2fVecLength(const std::string &file)
{
	std::vector<cv::Point2f> points;
	loadPoint2fVec(file,points);

	return points.size();
}

long MatrixUtil::getUcharVecLength(const std::string &file)
{
	std::vector<uchar> uchars;
	loadUcharVec(file,uchars);

	return uchars.size();
}

long MatrixUtil::getFloatVecLength(const std::string &file)
{
	std::vector<float> floats;
	loadFloatVec(file,floats);

	return floats.size();
}


