// -*- C++ -*-
/*!
* @file  OpenCV_RTC.cpp
* @brief ModuleDescription
* @date $Date$
*
* $Id$
*/

#include "OpenCV_RTC.h"
#include "ComponentAdmin.h"

// Module specification
// <rtc-template block="module_spec">
static const char* OpenCV_RTC_spec[] =
{
	"implementation_id", "OpenCV_RTC",
	"type_name",         "OpenCV_RTC",
	"description",       "OpenCV-RTC Component",
	"version",           "1.0.0",
	"vendor",            "UEC",
	"category",          "OpenCV-RTC",
	"activity_type",     "PERIODIC",
	"kind",              "DataFlowComponent",
	"max_instance",      "1",
	"language",          "C++",
	"lang_type",         "compile",
	""
};
// </rtc-template>

/*!
* @brief constructor
* @param manager Maneger Object
*/
OpenCV_RTC::OpenCV_RTC(RTC::Manager* manager)
	// <rtc-template block="initializer">
	: RTC::DataFlowComponentBase(manager)
	, componentAdmin()
	// </rtc-template>
{
	componentAdmin = ComponentAdminPtr( new ComponentAdmin( *this ) );
}

/*!
 * @brief destructor
 */
OpenCV_RTC::~OpenCV_RTC()
{
}


RTC::ReturnCode_t OpenCV_RTC::onInitialize()
{
	return componentAdmin->onInitialize();
}

RTC::ReturnCode_t OpenCV_RTC::onFinalize()
{
	return componentAdmin->onFinalize();
}


RTC::ReturnCode_t OpenCV_RTC::onStartup(RTC::UniqueId ec_id)
{
	return componentAdmin->onStartup();
}



RTC::ReturnCode_t OpenCV_RTC::onShutdown(RTC::UniqueId ec_id)
{
	return componentAdmin->onShutdown();
}



RTC::ReturnCode_t OpenCV_RTC::onActivated(RTC::UniqueId ec_id)
{
	return componentAdmin->onActivated();
}



RTC::ReturnCode_t OpenCV_RTC::onDeactivated(RTC::UniqueId ec_id)
{
	return componentAdmin->onDeactivated();
}



RTC::ReturnCode_t OpenCV_RTC::onExecute(RTC::UniqueId ec_id)
{
	componentAdmin->onExecute(this);
	return RTC::RTC_OK;
}


RTC::ReturnCode_t OpenCV_RTC::onAborting(RTC::UniqueId ec_id)
{
	return componentAdmin->onAborting();
}



RTC::ReturnCode_t OpenCV_RTC::onError(RTC::UniqueId ec_id)
{
	return componentAdmin->onError();
}



RTC::ReturnCode_t OpenCV_RTC::onReset(RTC::UniqueId ec_id)
{
	return componentAdmin->onReset();
}



RTC::ReturnCode_t OpenCV_RTC::onStateUpdate(RTC::UniqueId ec_id)
{
	return componentAdmin->onStateUpdate();
}



RTC::ReturnCode_t OpenCV_RTC::onRateChanged(RTC::UniqueId ec_id)
{
	return componentAdmin->onRateChanged();
}




extern "C"
{

	void OpenCV_RTCInit(RTC::Manager* manager)
	{
		coil::Properties profile(OpenCV_RTC_spec);
		manager->registerFactory(profile,
			RTC::Create<OpenCV_RTC>,
			RTC::Delete<OpenCV_RTC>);
	}

};


