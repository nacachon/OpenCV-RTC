#include "Retina.h"

void cvRetina(cv::Mat& src,	cv::Mat& magno,cv::Mat& parvo)
{
	cv::Ptr<cv::Retina> retina_image;
	retina_image = new cv::Retina(src.size());

	retina_image->run(src);
	retina_image->getParvo(parvo);
	retina_image->getMagno(magno);
}
