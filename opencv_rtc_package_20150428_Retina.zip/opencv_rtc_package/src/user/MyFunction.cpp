#include "MyFunction.h"

#include <iostream>
#include <boost/format.hpp>


void load_image( const std::string& file, cv::Mat& dst )
{
	IplImage* ipl = cvLoadImage( file.c_str() );
	cv::Mat image( ipl );
	image.copyTo( dst );
	cvReleaseImage( &ipl );
}






void test_vector( std::vector<cv::Point2f>& dst )
{
	dst.clear();
	dst.push_back( cv::Point(0,0) );
	dst.push_back( cv::Point(1,1) );
	dst.push_back( cv::Point(2,2) );
	dst.push_back( cv::Point(3,3) );
}


void test_matrix( cv::Mat& dst )
{
	dst = cv::Mat( 200, 200, CV_32FC1 );
}


void test_vmatrix_in( std::vector<cv::Mat>& vmat )
{

	for ( unsigned int i=0; i<vmat.size(); i++ ) {
		std::string window_name = (boost::format("test_%02d")%i).str();
		cv::imshow( window_name, vmat[i] );
		cv::waitKey(1);
	}


	/*
	for ( unsigned int i=0; i<vmat.size(); i++ ) {
		std::cerr << "matrix :" << i << std::endl;
		std::cerr << " width :" << vmat[i].cols << std::endl;
		std::cerr << " height:" << vmat[i].rows << std::endl;
		std::cerr << " type  :" << vmat[i].type() << std::endl;
		std::cerr << vmat[i] << std::endl;
	}

	std::cerr << "------------------------------------------------" << std::endl;
	*/
}


void test_vmatrix_out( std::vector<cv::Mat>& vmat )
{
	vmat.clear();
	const unsigned int vmat_size = 5;

	std::cerr << "output -----------------------------------------" << std::endl;

	for ( unsigned int i=0; i<vmat_size; ++i ) {
		cv::Mat mat( i+1, i+1, CV_8UC1 );
		cv::randu(mat, cv::Scalar(0), cv::Scalar(256));
		vmat.push_back( mat );

		std::cerr << "matrix :" << i << std::endl;
		std::cerr << " width :" << mat.cols << std::endl;
		std::cerr << " height:" << mat.rows << std::endl;
		std::cerr << " type  :" << mat.type() << std::endl;
		std::cerr << mat << std::endl;
	}

	std::cerr << "------------------------------------------------" << std::endl;
}


