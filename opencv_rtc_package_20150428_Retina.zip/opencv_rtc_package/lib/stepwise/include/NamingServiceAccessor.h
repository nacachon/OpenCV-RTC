// -*- C++ -*-
/*!
 * @file NamingServiceAccessor.h
 * @brief NamingServiceAccessor class
 * @date $Date: 2008-01-14 07:53:05 $
 * @author 
 *
 * $Id:  $
 *
 */

#ifndef _NAMINGSERVICEACCESSOR_H_
#define _NAMINGSERVICEACCESSOR_H_

#include <string>
#include <vector>
#include <rtm/CorbaNaming.h>
#include <rtm/SystemLogger.h>

namespace RTC
{
/// ネーミングサービスへのアクセスを行う
class NamingServiceAccessor
{
public:
    /// コンストラクタ
    /**
     * @param orb      CORBAのORBオブジェクトリファレンス
     * @param location ネーミングサービスの場所(IPアドレス:ポート番号)
     * @note 引数orbは内部でduplicateされる
     */
    NamingServiceAccessor(CORBA::ORB_ptr orb, const std::string& location);

    /// デストラクタ
    ~NamingServiceAccessor();

    /// 与えられた名前のオブジェクトを解決する
    /**
     *
     * @param object_name 解決したいオブジェクト名のフルネーム(HostA.host_cxt/Rtc0.rtcなど)
     * @return 解決したオブジェクトリファレンス
     * @attention オブジェクト解決に失敗した場合,例外が投げられる.
     * @note 例外が投げられなかった場合,返したオブジェクトリファレンスは
     *       nilでないことが保証される.
     */
    CORBA::Object_ptr resolveObjectByName(const std::string& object_name);

    /// 与えられた種類に当てはまるオブジェクト名の一覧を返す
    /**
     * 現在ネーミングサービスに登録されているオブジェクトリファレンスのうち,
     * 引数で与えられた種類(ConsoleIn0.rtcなら"rtc")に当てはまるものの
     * フルネームの一覧を返す.
     * @param object_kind オブジェクトの種類
     *                    (ConsoleIn0.rtcなら"rtc", manager.mgrなら"mgr")
     * @return 与えられた種類に当てはまるオブジェクト名の一覧
     */
    std::vector<std::string> listObjectName(const std::string& object_kind);
    
protected:
    /*!
     * @if jp
     * @brief ロガーストリーム
     * @else
     * @brief Logger stream
     * @endif
     */
    mutable Logger rtclog;

private:
    /// 指定されたコンテキストから登録されているオブジェクト名の一覧を返す
    /**
     * 本メソッドは再帰を用いて処理を行う.
     * 指定されたコンテキストに登録されているオブジェクトを全て列挙することを
     * 再帰的に繰り返すことで,深いコンテキストに登録されているオブジェクト名も全て
     * 返す.
     * @param naming_context 登録されているオブジェクトを列挙するコンテキスト
     * @param prefix オブジェクト名に付与するプレフィックス
     * @param object_kind オブジェクトの種類
     *                    (ConsoleIn0.rtcなら"rtc", manager.mgrなら"mgr")
     * @return 指定されたコンテキストから登録されているオブジェクト名の一覧
     */
    std::vector<std::string>
            listObjectNameInSpecificContext(const CosNaming::NamingContext_ptr naming_context,
                                            const CosNaming::Name& prefix,
                                            const std::string& object_kind);

    /// CORBAのネーミングサービスへのアクセサ
    RTC::CorbaNaming corba_naming_service_;
};
} // namespace system_manager

#endif // _NAMINGSERVICEACCESSOR_H_
