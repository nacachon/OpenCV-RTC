// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file StepwiseExecutionContextStub.cpp 
 * @brief StepwiseExecutionContext client stub wrapper code
 * @date Mon Jul 07 13:33:37 2014 
 *
 */

#include "StepwiseExecutionContextStub.h"

#if   defined ORB_IS_TAO
#  include "StepwiseExecutionContextC.cpp"
#elif defined ORB_IS_OMNIORB
#  include "StepwiseExecutionContextSK.cc"
#  include "StepwiseExecutionContextDynSK.cc"
#elif defined ORB_IS_MICO
#  include "StepwiseExecutionContext.cc"
#elif defined ORB_IS_ORBIT2
#  include "StepwiseExecutionContext-cpp-stubs.cc"
#elif defined ORB_IS_RTORB
#  include "OpenRTM-aist-decls.h"
#  include "StepwiseExecutionContext-common.c"
#  include "StepwiseExecutionContext-stubs.c"
#else
#  error "NO ORB defined"
#endif

// end of StepwiseExecutionContextStub.cpp
