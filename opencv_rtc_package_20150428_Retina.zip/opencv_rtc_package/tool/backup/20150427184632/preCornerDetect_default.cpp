// This file is created automatically.
#include <preCornerDetect_default.h>

RTC::ReturnCode_t preCornerDetect_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t preCornerDetect_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t preCornerDetect_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t preCornerDetect_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t preCornerDetect_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t preCornerDetect_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t preCornerDetect_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t preCornerDetect_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t preCornerDetect_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t preCornerDetect_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t preCornerDetect_default::onRateChanged()
{
    return RTC::RTC_OK;
}