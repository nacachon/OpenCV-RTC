// This file is created automatically.
#include <bilateralFilter_default.h>

RTC::ReturnCode_t bilateralFilter_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t bilateralFilter_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t bilateralFilter_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t bilateralFilter_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t bilateralFilter_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t bilateralFilter_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t bilateralFilter_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t bilateralFilter_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t bilateralFilter_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t bilateralFilter_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t bilateralFilter_default::onRateChanged()
{
    return RTC::RTC_OK;
}