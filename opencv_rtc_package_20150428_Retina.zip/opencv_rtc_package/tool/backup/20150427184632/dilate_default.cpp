// This file is created automatically.
#include <dilate_default.h>

RTC::ReturnCode_t dilate_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t dilate_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t dilate_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t dilate_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t dilate_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t dilate_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t dilate_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t dilate_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t dilate_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t dilate_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t dilate_default::onRateChanged()
{
    return RTC::RTC_OK;
}