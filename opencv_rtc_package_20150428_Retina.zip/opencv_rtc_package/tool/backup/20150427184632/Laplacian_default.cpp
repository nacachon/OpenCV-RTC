// This file is created automatically.
#include <Laplacian_default.h>

RTC::ReturnCode_t Laplacian_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Laplacian_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Laplacian_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Laplacian_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Laplacian_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Laplacian_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Laplacian_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Laplacian_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Laplacian_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Laplacian_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t Laplacian_default::onRateChanged()
{
    return RTC::RTC_OK;
}