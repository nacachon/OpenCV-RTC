// This file is created automatically.
#include <cornerHarris_default.h>

RTC::ReturnCode_t cornerHarris_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerHarris_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerHarris_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerHarris_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerHarris_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerHarris_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerHarris_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerHarris_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerHarris_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerHarris_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerHarris_default::onRateChanged()
{
    return RTC::RTC_OK;
}