// This file is created automatically.
#include <cornerMinEigenVal_default.h>

RTC::ReturnCode_t cornerMinEigenVal_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerMinEigenVal_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerMinEigenVal_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerMinEigenVal_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerMinEigenVal_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerMinEigenVal_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerMinEigenVal_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerMinEigenVal_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerMinEigenVal_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerMinEigenVal_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t cornerMinEigenVal_default::onRateChanged()
{
    return RTC::RTC_OK;
}