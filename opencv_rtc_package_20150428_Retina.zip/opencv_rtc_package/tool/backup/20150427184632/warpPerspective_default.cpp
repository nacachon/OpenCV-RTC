// This file is created automatically.
#include <warpPerspective_default.h>

RTC::ReturnCode_t warpPerspective_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t warpPerspective_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t warpPerspective_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t warpPerspective_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t warpPerspective_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t warpPerspective_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t warpPerspective_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t warpPerspective_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t warpPerspective_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t warpPerspective_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t warpPerspective_default::onRateChanged()
{
    return RTC::RTC_OK;
}