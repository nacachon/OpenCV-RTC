// This file is created automatically.
#include <resize_default.h>

RTC::ReturnCode_t resize_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t resize_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t resize_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t resize_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t resize_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t resize_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t resize_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t resize_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t resize_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t resize_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t resize_default::onRateChanged()
{
    return RTC::RTC_OK;
}