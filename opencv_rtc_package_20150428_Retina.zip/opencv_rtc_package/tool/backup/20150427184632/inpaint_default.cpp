// This file is created automatically.
#include <inpaint_default.h>

RTC::ReturnCode_t inpaint_default::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t inpaint_default::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t inpaint_default::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t inpaint_default::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t inpaint_default::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t inpaint_default::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t inpaint_default::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t inpaint_default::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t inpaint_default::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t inpaint_default::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t inpaint_default::onRateChanged()
{
    return RTC::RTC_OK;
}