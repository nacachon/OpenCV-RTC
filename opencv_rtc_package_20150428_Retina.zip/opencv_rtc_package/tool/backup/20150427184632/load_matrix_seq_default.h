#ifndef _load_matrix_seq_default_H
#define _load_matrix_seq_default_H

#include <Function.h>

using namespace std;
using namespace cv;

class load_matrix_seq_default:
  public  Function<void (std::string&,cv::Mat&,int&)>
{
public:
    /*!
     * @brief Constructor
     * @param[in] name  PortName
     * @param[in] param 
     */
    load_matrix_seq_default( 
        RTC::RTObject_impl& obj,
        const std::string& name,
        FuncType func,
        ParameterT<void> p0,
        ParameterT<std::string&> p1,
        ParameterT<cv::Mat&> p2,
        ParameterT<int&> p3
        ) : 
        Function<void (std::string&,cv::Mat&,int&)>(obj, name, func, p0, p1, p2, p3)
    {};

    virtual RTC::ReturnCode_t onInitialize();
    virtual RTC::ReturnCode_t onStartup();
    virtual RTC::ReturnCode_t onActivated();
    virtual RTC::ReturnCode_t onDeactivated();
    virtual RTC::ReturnCode_t onShutdown();
    virtual RTC::ReturnCode_t onFinalize();
    virtual RTC::ReturnCode_t onAborting();
    virtual RTC::ReturnCode_t onError();
    virtual RTC::ReturnCode_t onReset();
    virtual RTC::ReturnCode_t onStateUpdate();
    virtual RTC::ReturnCode_t onRateChanged();

};

#endif // _load_matrix_seq_default_H
