// This file is created automatically.
#include <${func.classname}.h>

RTC::ReturnCode_t ${func.classname}::onInitialize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t ${func.classname}::onStartup()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t ${func.classname}::onActivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t ${func.classname}::onDeactivated()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t ${func.classname}::onShutdown()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t ${func.classname}::onFinalize()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t ${func.classname}::onAborting()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t ${func.classname}::onError()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t ${func.classname}::onReset()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t ${func.classname}::onStateUpdate()
{
    return RTC::RTC_OK;
}

RTC::ReturnCode_t ${func.classname}::onRateChanged()
{
    return RTC::RTC_OK;
}
