// This file is created automatically.

#include <boost/format.hpp>
#include <StepwiseSystem.h>
#include <MyLoopBackConditionManager.h>
#include <MyLoopBackCondition.h>
#include <MatrixUtil.h>

using namespace cv;
using namespace std;

MyLoopBackConditionManager::~MyLoopBackConditionManager(){
    delete condition;
};

void MyLoopBackConditionManager::initialize(std::string &func_name)
{
% for function in functions
    if ( func_name == "${function.rawname}" ) {
        condition = new LoopBackCondition${function.name}(object);
    }
% endfor
}

bool MyLoopBackConditionManager::useInitialData( const std::string &inport_name )
{
    return condition->useInitialData(inport_name);
}
    
void MyLoopBackConditionManager::getInitialData( const std::string &inport_name )
{
    condition->getInitialData(inport_name);
}

% for function in functions
bool LoopBackCondition${function.name}::useInitialData( const std::string & portname )
{
    bool useInitialData = false;

    % for config in function.configs
    ParameterT<${config.type}> *p_${config.name} = (ParameterT<${config.type}> *)getParam( "${config.name}" );
    % endfor

    % for inport in function.inports
    if ( portname == (boost::format("%s.${inport.name}")%object.getInstanceName()).str() ) {
        % if inport.hasCondition
        if ( ${inport.condition} ) {
            useInitialData = true;
        } 
        % endif
    }
    % endfor
    return useInitialData;
}
void LoopBackCondition${function.name}::getInitialData( const std::string & portname )
{
    % for inport in function.inports
    if ( portname == (boost::format("%s.${inport.name}")%object.getInstanceName()).str() ) {
        ${inport.setdata}
    }
    % endfor
}

% endfor
