// This file is created automatically.

#include <ConfigurationManager.h>
#include <ConfigurationHolder.h>
#include <MyConfigurationManager.h>

using namespace std;

bool MyConfigurationManager::initialize()
{
% for function in functions
    % for config in function.configs
    setConfig( "${function.name}", (ParameterBase *)(new ParameterT<${config.type}>("${config.name}","param","",${config.value},"")) );
    % endfor
% endfor
    
    return true;
}

