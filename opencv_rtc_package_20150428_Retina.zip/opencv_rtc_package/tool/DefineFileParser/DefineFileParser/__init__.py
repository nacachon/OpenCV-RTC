# -*- coding: utf-8 -*-
# DefineFileParser package

from DefineFileParser import *

#__all__ = ['DefineFileParser']
