# -*- coding: utf-8 -*-
import os
import re
import ply.lex as lex
from jinja2 import Environment as JinjaEnvironment

# List of token names. This is always required
tokens = (
    'NAME',
    'OPEN_PAREN',
    'CLOSE_PAREN',
    'OPEN_BRACE',
    'CLOSE_BRACE',
    'OPEN_SQUARE_BRACKET',
    'CLOSE_SQUARE_BRACKET',
#     'DOUBLE_QUOTATION',
#     'COLON',
    'SEMI_COLON',
    'REFERENCE',
    'POINTER',
    'SEPARATOR',
    'ATTRIBUTE',
    'COMMENT',
    'INCLUDE',
    'NAMESPACE',
    'EQUAL',
    'SLASH',
    'STRING',
    'KEYWORD',
    'MODULO'
)

INT_TYPE_LIST           = '(unsigned )?(short |long )?int'
CHAR_TYPE_LIST          = '(unsigned )?char'
DOUBLE_TYPE_LIST        = '(long )?double'
STRING_TYPE_LIST        = '(std::)?string'
CV_DATATYPE_LIST        = '(cv::)?(Mat|Scalar|Point|Size|TermCriteria|Point2f)'
PRIMITIVETYPE_LIST      = 'void|float|bool|uchar|long|%s|%s|%s|%s'%(INT_TYPE_LIST,CHAR_TYPE_LIST,DOUBLE_TYPE_LIST,STRING_TYPE_LIST)
PRIMITIVETYPE_ELE_LIST  = 'void|char|short|int|long|float|double|signed|unsigned|(std::)?string|bool|uchar'
VECTOR_DATA_LIST        = '(std::)?vector<((cv::)?Point2f|(cv::)?Mat|uchar|float)>'
DATATYPE_LIST           = '%s|%s|%s'%(PRIMITIVETYPE_LIST, CV_DATATYPE_LIST, VECTOR_DATA_LIST)
DATATYPE_ELE_LIST       = '^(%s|%s|%s)$'%(PRIMITIVETYPE_ELE_LIST, CV_DATATYPE_LIST, VECTOR_DATA_LIST)
SPEC_LIST               = 'const|static|auto|extern|typedef'
ATTRIBUTE_LIST          = 'param|list|outport|inport'
RET_ATTRIBUTE_LIST      = 'outport|unused'


# Regular expression rules for simple tokens
t_ignore                    = " \r.?\f\t"
t_NAME                      = r'[<>A-Za-z_\d\-\+][A-Za-z0-9_:\.\-<>\+]*'
t_OPEN_PAREN                = r'\('
t_CLOSE_PAREN               = r'\)'
t_OPEN_BRACE                = r'{'
t_CLOSE_BRACE               = r'}'
t_OPEN_SQUARE_BRACKET       = r'\['
t_CLOSE_SQUARE_BRACKET      = r'\]'
# t_DOUBLE_QUOTATION          = r'"'
# t_COLON                     = r':'
t_SEMI_COLON                = r';'
t_REFERENCE                 = r'\&'
t_POINTER                   = r'\*'
t_SEPARATOR                 = r','
t_ATTRIBUTE                 = r'@'
t_COMMENT                   = r'//.*'
t_INCLUDE                   = r'\#include.*'
t_NAMESPACE                 = r'\#namespace.*'
t_EQUAL                     = r'='
t_SLASH                     = r'\/'
t_STRING                    = r'"([^"\\]|\\.)*"'
t_KEYWORD                   = r'\$\(\ *[A-Za-z_][A-Za-z0-9_\.]*\ *\)'
t_MODULO                    = r'%'

IMAGE_FILE_EXTS = (
    '.bmp',
    '.dib',
    '.jpeg',
    '.jpg',
    'jpe'
)

MATRIX_FILE_EXTS = (
    '.xml'
)


class TemplateObj():
    def add(self,key,value):
        setattr(self,key,value)

# Define a rule so we can track line numbers
def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

# Error handling rule
def t_error(t):
    print "Illegal character '%s'" % t.value[0]
    t.lexer.skip(1)

def check_type(value, reg ):
    return re.match(reg, value)

def is_datatype( value ):
    return check_type( value, DATATYPE_LIST )

def is_datatype_element( value ):
    return check_type( value, DATATYPE_ELE_LIST )

def is_attribute( value ):
    return check_type( value, ATTRIBUTE_LIST )

def is_enum( value ):
    return check_type( value, 'enum' )

def is_initialdata( value ):
    return check_type( value, 'initialdatalist' )

def is_ret_attribute( value ):
    return check_type( value, RET_ATTRIBUTE_LIST )


"""
 @brief 関数に関する空の辞書データを作成する
 @return 関数の辞書データ
"""
def createFunctionDict():
    function = {"return":"None", "attr":"None", "reference":"None", "name":"None", "params":[], "configs":[], "authors":[]}
    return function

def createParameterDict():
    param = {"type":"None", "reference":False, "pointer":False, "name":"None", "attr":"None", "value":"None", "option":"None", "detail":"None"}
    return param

def createConfigDict():
    param = {"type":"None", "name":"None", "value":"None"}
    return param

def createEnumDict():
    param = {"name":"None", "params":[] }
    return param

def createEnumValueDict():
    param = {"name":"None", "value":"None"}
    return param

def createInitialDataDict():
    param = {"type":"None", "name":"None", "source":"None", "value":"None","elementes":0}
    return param

"""
@brief 構文エラー用例外クラス
"""
class SyntaxException(Exception):
    def __init__(self, token, msg):
        (self.token, self.msg) = (token, msg)
    def __str__(self):
        if self.token != None:
            return "SyntaxError    : lineno=>%s value=>%s msg=>%s" %(self.token.lineno, self.token.value, self.msg)
        else:
            return "SyntaxError : %s" %(self.msg)

class DataTypeException(Exception):
    def __init__(self, token, msg):
        (self.token, self.msg) = (token, msg)
    def __str__(self):
        if self.token != None:
            return "DataTypeError  : lineno=>%s value=>%s msg=>%s" %(self.token.lineno, self.token.value, self.msg)
        else:
            return "DataTypeError : %s" %(self.msg)

class AttributeException(Exception):
    def __init__(self, token, msg):
        (self.token, self.msg) = (token, msg)
    def __str__(self):
        if self.token != None:
            return "AttributeError : lineno=>%s value=>%s msg=>%s" %(self.token.lineno, self.token.value, self.msg)
        else:
            return "AttributeError : %s" %(self.msg)


class DefineFileAnalyzer():

    def __init__(self, data):

        # Build the lexer
        lexer = lex.lex()

        # 関数一覧
        self.function_list    = []
        self.enum_list        = []
        self.initialdata_list = []
        self.namespace_list   = []
        self.include_list     = []

        # Give the lexer some input
        lexer.input(data)

        # 使用する変数一覧
        stack         = []

        # ファイルの分析を実行する
        while True:
            token = lexer.token()
            if not token: break      # No more input

            # セミコロンが発生した場合、積まれたスタックの分析を行う
            if token.type == 'SEMI_COLON':
                self._analyzeStack(stack)
                stack = []

            # include 記述を分離
            elif token.type == 'INCLUDE':
                self.include_list.append(token.value)
                if len(stack) > 0:
                    msg = ""
                    raise SyntaxException(stack[0],msg)

            # namespace を分離
            elif token.type == 'NAMESPACE':
                self.namespace_list.append(token.value)
                if len(stack) > 0:
                    msg = ""
                    raise SyntaxException(stack[0],msg)

            # コメントを無視
            elif token.type == 'COMMENT':
                pass

            # その他の文字列であれば、一度スタックに積む
            else:
                stack.append(token)

        # enum値のバリデート処理を実行する
        for function in self.function_list:
            self._validateListAttribute(self.enum_list, function)

        # InPortの初期条件、初期データのバリデート処理を実行する
        for function in self.function_list:
            self._validateInPortInitialData(self.initialdata_list, function)


    """.
    @brief 実行可能処理(MyFUnctionManager)を生成する
    @param[in] template  テンプレートファイルから読み込んだデータ
    @return              生成した結果文字列

    """
    def createMyFunctionManager(self, template):

        context = {
            'includes':[],
            'function_strs':[],
            'functions':[]
            }

        include_output  = ""
        function_output = ""

        # インクルード文を作成
        context['includes'] = self.include_list

        # 関数定義文を作成
        for func in self.function_list:
            for author in func['authors']:
                funcobj = TemplateObj()
                funcobj.add( 'name',func['name'])
                funcobj.add( 'classname',self._createFuncClassname(func['name'],author))
                context['functions'].append(funcobj)
                func_str = self._createFunctionStr( func, author )
                # 改行等
                func_str = func_str.replace('\n', '\n\t')
                context['function_strs'].append(func_str)

        template = JinjaEnvironment(
            line_statement_prefix='%',
            variable_start_string="${",
            variable_end_string="}"
            ).from_string(template)
        return template.render(context)

    """.
    @brief 実行可能処理(MyLoopbackCondition)を生成する
    @param[in] template  テンプレートファイルから読み込んだデータ
    @return              生成した結果文字列

    """
    def createMyLoopbackCondition(self, template):

        context = {
            'functions':[]
            }

        for function in self.function_list:

            for author in function['authors']:
                func = TemplateObj()
                #func.add( 'rawname',self._createFuncClassname(function['name'],author))
                func.add( 'rawname','%s'%self._createFuncName(function['name'],author))
                func.add( 'name',self._createFuncClassname(function['name'],author))
                func.add( 'inports',[])
                func.add( 'configs',[])

                for param in function['params']:
                    if param['attr']=='inport':
                        inport = TemplateObj()
                        inport.name = param['name']
                        if param['option'] == 'None':
                            inport.add('hasCondition',False)
                        else:
                            inport.add('hasCondition',True)
                            inport.add('condition',param['option'])

                            data = self._getInitialdata(param['value'])
                            setdatastr = ""
                            if data['type'] == 'cv::Mat':
                                if data['source'] == 'image':
                                    setdatastr = self._createLoadImageStr(inport.name,data['name'])
                                else:
                                    setdatastr = self._createLoadMatrixStr(inport.name,data['name'])
                            elif data['type'] == 'std::vector<cv::Mat>':
                                if data['source'] == 'image':
                                    setdatastr = self._createLoadImageVectorStr(inport.name,data['name'])
                                else:
                                    setdatastr = self._createLoadMatrixVectorStr(inport.name,data['name'])
                            elif data['type'] == 'std::vector<cv::Point2f>':
                                setdatastr = self._createLoadPoint2fStr(inport.name,data['name'])
                            elif data['type'] == 'std::vector<uchar>':
                                setdatastr = self._createLoadUcharStr(inport.name,data['name'])
                            elif data['type'] == 'std::vector<float>':
                                setdatastr = self._createLoadFloatStr(inport.name,data['name'])
                            else:
                                # 発生しないはず
                                raise Exception('unknown error.')

                            inport.add('setdata', setdatastr)
                        func.inports.append(inport)
                context['functions'].append(func)

                for config in function['configs']:
                    confobj = TemplateObj()
                    confobj.add('name',config['name'])
                    confobj.add('type',config['type'])
                    func.configs.append(config)

        template = JinjaEnvironment(
            line_statement_prefix='%',
            variable_start_string="${",
            variable_end_string="}"
            ).from_string(template)
        return template.render(context)

    """.
    @brief 実行可能処理(MyConfigurationManager.cpp)を生成する
    @param[in] template  テンプレートファイルから読み込んだデータ
    @return              生成した結果文字列

    """
    def createMyConfigurationManager(self, template):

        context = {
            'functions':[]
            }
        for function in self.function_list:
            for author in function['authors']:
                func = TemplateObj()
                # func.add('name', self._createFuncClassname( function['name'], author) )
                func.add('name', '%s'%(self._createFuncName(function['name'], author)) )
                func.add( 'configs',[])
                for config in function['configs']:
                    confobj = TemplateObj()
                    confobj.add('type',config['type'])
                    confobj.add('name',config['name'])
                    confobj.add('value',config['value'])
                    func.configs.append(confobj)
                context['functions'].append(func)

        template = JinjaEnvironment(
            line_statement_prefix='%',
            variable_start_string="${",
            variable_end_string="}"
            ).from_string(template)
        return template.render(context)

    """.
    @brief 実行可能処理(MyFunctionXXXX.cpp)を生成する
    @param[in] template  テンプレートファイルから読み込んだデータ
    @return              生成した結果文字列

    """
    def createMyFunction(self, function, author, template):

        func = self._getFunction(function)

        params = []
        constructorparam = ""

        funcobj = TemplateObj()
        funcobj.add('name',func['name'])
        funcobj.add('classname',self._createFuncClassname(func['name'],author))
        typestr = func['return']
        constructorparam = "p0"
        if len(func['params'])>0:
            params.append("ParameterT<%s> p0," % func['return'])
            typestr += " ("
            for cnt in range(len(func['params'])):
                param = func['params'][cnt]
                typestr += param['type']
                if param['reference'] == True:
                    typestr += '&'
                    paramstr = "ParameterT<%s&> p%d" % (param['type'],(cnt+1))
                else:
                    paramstr = "ParameterT<%s> p%d" % (param['type'],(cnt+1))
                constructorparam += ", p%d"%(cnt+1)

                if cnt != len(func['params'])-1:
                    typestr += ","
                    paramstr += ","
                params.append(paramstr)
            typestr += ")"
        else:
            params.append("ParameterT<%s> p0" %func['return'])

        funcobj.add('type',typestr)
        funcobj.add('params',params)

        context = {
            'func':funcobj,
            'constructorparam':constructorparam
            }

        template = JinjaEnvironment(
            line_statement_prefix='%',
            variable_start_string="${",
            variable_end_string="}"
            ).from_string(template)
        return template.render(context)


    # Function一覧の取得
    def getFunctionList(self):
        return self.function_list

    def _createFuncName(self,funcname,author):
        if (author=='default'):
            return '%s'%(funcname)
        else:
            return '%s_(%s)'%(funcname,author)


    def _createFuncClassname(self,funcname,author):
        return '%s_%s'%(funcname,author)


    """
     @brief 指定した名前を持つ列挙体定義を文字列に変換する
     @param[in] name      文字列化する列挙体の名前
     @return              文字列化した列挙体
    """
    def _createEnumStr(self, name):
        output = ""
        enum   = {}

        # 目的のENUM値を取得する
        for value in self.enum_list:
            if value["name"] == name:
                enum = value["params"]
                break

        # ENUMを文字列変換した値を取得する
        for value in enum:
            output += ("%s:%s,") %(value["name"], value["value"])
        output = output[:-1]
        return output


    """
     @brief 関数用の文字列を作成する関数
     @param[in] function 関数ディクショナリ
     @return    文字列生成結果
    """
    def _createFunctionStr(self, function, author):
        output = '\n// %s function\n'%(function["name"])
        output += 'registerFunction( \n\t'
        output += 'FuncPtr( new %s' % self._createFuncClassname(function['name'],author)

        output += '(object, "%s", %s' %(self._createFuncName(function["name"], author), function["name"])

        param = createParameterDict()
        param['name'] = 'return'
        param['type'] = function['return']
        param['attr'] = function['attr']
        output += self._createParamStr(param)


        for param in function["params"]:
            output += self._createParamStr( param )

        output += '\n)));'
        return output


    # パラメータ文字列を作成する
    def _createParamStr(self, param):
            # 初期化用文字列作成

            # inportの初期データ代入はMyLoopbackManagerで行うため、初期値は不要。
            # ただし、オブジェクトは生成する
            init_str = ""
            if param['attr']=='inport':
                init_str = ("%s()") %(param["type"])
            else:
                # cv::Mat型のみ、入力に文字列を許可しているため特別な処理を行う
                if param["value"] == "None" or param["type"] == "cv::Mat":
                    init_str = ("%s()") %(param["type"])
                else:
                    init_str = param["value"]
                    init_str = ("%s")%init_str

            # ENUM値の作成
            enum_str = "\"\""
            detail_str = "\"\""
            if param["attr"] == "list":
                enum_str = self._createEnumStr( param["option"] )
                enum_str = ("\"%s\"")%enum_str
                detail_str = ("\"%s\"")%param['detail']
                init_str   = "0"
            elif param["attr"] == "inport":
                # inportの初期値はパラメータ文字列としない
                pass
            else:
                if param["type"] == "cv::Mat":
                    if param["value"] != "None":
                        enum_str = param["value"]

            output = ""
            output += ',\n'
            output += '\tParameterT<%s'%(param["type"])
            output += '&' if param["reference"] == True else ""

            if param['type'] == "void":
                output += ">(\"%s\",\"%s\",%s)"%(param["name"], param["attr"], enum_str)
            else:
                output += ">(\"%s\",\"%s\",%s,%s,%s)"%(param["name"], param["attr"], enum_str, init_str, detail_str)

            return output

    def _createLoadImageStr(self,port_config,dataname):
        return '''\
ParameterBase *param = getParam("%s");
        cv::Mat &img = ((ParameterT<cv::Mat> *)param)->getValue();
        ParameterT<std::string> *param_inidata = (ParameterT<std::string> *)getParam("%s");
        img = cv::imread(param_inidata->getValue());'''%(port_config,dataname)

    def _createLoadMatrixStr(self,port_config,dataname):
        return '''\
ParameterBase *param = getParam("%s");
        cv::Mat &mat = ((ParameterT<cv::Mat> *)param)->getValue();
        ParameterT<std::string> *param_inidata = (ParameterT<std::string> *)getParam("%s");
        MatrixUtil::loadMatrix(param_inidata->getValue(), mat );'''%(port_config,dataname)

    def _createLoadImageVectorStr(self,port_config,dataname):
        return '''\
ParameterBase *param = getParam("%s");
    	std::vector<cv::Mat> &imgs = ((ParameterT<std::vector<cv::Mat>> *)param)->getValue();
        ParameterT<std::string> *param_inidata = (ParameterT<std::string> *)getParam("%s");
        ParameterT<long> *param_vecsize = (ParameterT<long> *)getParam("%s_size");
        long vecsize = param_vecsize->getValue();
        imgs.resize(0);
        if ( vecsize > 0 ) {
            cv::Mat img = cv::imread(param_inidata->getValue());
        	for (int i=0; i<vecsize; i++) {
                imgs.push_back(img);
            }
        }'''%(port_config,dataname,dataname)

    def _createLoadMatrixVectorStr(self,port_config,dataname):
        return '''\
ParameterBase *param = getParam("%s");
        std::vector<cv::Mat> &mats = ((ParameterT<std::vector<cv::Mat>> *)param)->getValue();
        ParameterT<std::string> *param_inidata = (ParameterT<std::string> *)getParam("%s");
        MatrixUtil::loadMatrixVec(param_inidata->getValue(), mats );'''%(port_config,dataname)

    def _createLoadPoint2fStr(self,port_config,dataname):
        return '''\
ParameterBase *param = getParam("%s");
        std::vector<cv::Point2f> &points = ((ParameterT<std::vector<cv::Point2f>> *)param)->getValue();
        ParameterT<std::string> *param_inidata = (ParameterT<std::string> *)getParam("%s");
        MatrixUtil::loadPoint2fVec(param_inidata->getValue(), points );'''%(port_config,dataname)

    def _createLoadUcharStr(self,port_config,dataname):
        return '''\
ParameterBase *param = getParam("%s");
        std::vector<uchar> &uchars = ((ParameterT<std::vector<uchar>> *)param)->getValue();
        ParameterT<std::string> *param_inidata = (ParameterT<std::string> *)getParam("%s");
        MatrixUtil::loadUcharVec(param_inidata->getValue(), uchars );'''%(port_config,dataname)

    def _createLoadFloatStr(self,port_config,dataname):
        return '''\
ParameterBase *param = getParam("%s");
        std::vector<float> &floats = ((ParameterT<std::vector<float>> *)param)->getValue();
        ParameterT<std::string> *param_inidata = (ParameterT<std::string> *)getParam("%s");
        MatrixUtil::loadFloatVec(param_inidata->getValue(), floats );'''%(port_config,dataname)


    # スタックの解析を行う
    def _analyzeStack(self,stack):
        # スタックに積まれた最初のトークンより、分析する型を決定
        token = stack[0]

        # enum型の分析を行う
        if is_enum( token.value ):
            enum = self._analyzeEnum( stack )
            self.enum_list.append(enum)

        # initialdata型の分析を行う
        elif is_initialdata( token.value ):
            initialdata = self._analyzeInitialData( stack )
            if len(self.initialdata_list) == 0:
                self.initialdata_list.append(initialdata)
            else:
                raise SyntaxException(token,"Multiple initialdata definition.")

        # 関数の分析を行う
        else:
            function = self._analyzeFunction( stack )
            self.function_list.append(function)

    #  STACKより、データを取得する
    def _getStackData(self,stack,token_type,msg=""):
        token = stack.pop(0)
        if token.type == token_type :
            return token.value
        else:
            raise SyntaxException(token,msg)

    # STACKより、データ型を取得する
    def _getStackDataType(self,stack):
        data_type = ""
        data_type_list = []

        # データ型を取得する
        begin_token = stack[0]
        token = stack[0]
        while is_datatype_element(token.value):
            data_type_list.append( token.value )
            self._getStackData(stack, 'NAME')
            token = stack[0]

        # データ型を整形する
        for cnt in range(len(data_type_list)):
            data_type += data_type_list[cnt]
            if cnt != len(data_type_list)-1 :
                data_type += " "

        # データ型を判別する
        if is_datatype(data_type):
            return data_type
        else:
            raise DataTypeException(begin_token,"Unsupported DataType")


    # ENUMの分析を行う
    def _analyzeEnum(self,stack):
        # 返り値作成
        enum = createEnumDict()

        # 最初のトークン enum を呼び飛ばす
        stack.pop(0)

        # Enumの名前を取得する
        enum['name'] = self._getStackData(stack,'NAME')

        # 次のトークン { を取得
        self._getStackData(stack,'OPEN_BRACE')

        # ENUM要素の分析を行う
        while True:
            value = self._analyzeEnumElement( stack )
            enum["params"].append(value)

            # 終了判定
            token = stack.pop(0)
            if token.type == 'CLOSE_BRACE':
                break

        return enum


    # ENUM要素の分析を行う
    def _analyzeEnumElement(self,stack):
        try:
            value = createEnumValueDict()

            # 要素の名前を取得する
            value['name'] = self._getStackData(stack, 'NAME')

            # 次のトークン = を取得する
            self._getStackData(stack, 'EQUAL')

            # 次のトークン 値 を取得する
            value['value'] = self._getStackData(stack, 'NAME')

        except SyntaxException as e:
            e.msg = 'Invalid enum element'
            raise

        return value


    # INITIALDATALISTの分析を行う
    def _analyzeInitialData(self,stack):
        # 返り値作成
        initialdatalist = []

        # 最初のトークン initialdatalist を呼び飛ばす
        stack.pop(0)

        # 次のトークン { を取得
        self._getStackData(stack,'OPEN_BRACE')

        # INITIALDATALIST要素の分析を行う
        while True:
            initialdata = self._analyzeInitialdataElement( stack )
            # 同じ名前のデータの重複チェック
            for data in initialdatalist:
                if data['name'] == initialdata['name']:
                    raise SyntaxException(token,"%s:Multiple definition."%initialdata['name'])

            initialdatalist.append(initialdata);
            # 終了判定
            token = stack.pop(0)
            if token.type == 'CLOSE_BRACE':
                break
            elif token.type == 'SEPARATOR':
                # 継続して解析
                pass
            else:
                raise SyntaxException(token,"Illegal character.")

        return initialdatalist


    # INITIALDATALIST要素の分析を行う
    def _analyzeInitialdataElement(self,stack):
        try:
            # 返り値作成
            value = createInitialDataDict()

            # 要素の型名を取得する
            value['type'] = self._getStackData(stack, 'NAME')

            # 要素の名前を取得する
            value['name'] = self._getStackData(stack, 'NAME')

            # 次のトークン = を取得する
            self._getStackData(stack, 'EQUAL')

            if value['type'] == "cv::Mat":
                # cv::Mat型のデータ指定は"ファイル名". ファイル名の拡張子で
                # 画像か行列かを見分ける

                # ファイル名を取得
                filename =self._getStackData(stack, 'STRING')
                filename = filename[1:len(filename)-1]
                root, ext = os.path.splitext(filename)

                # 画像データの場合
                if (ext in IMAGE_FILE_EXTS):
                    value['value'] = filename
                    value['source'] ="image"
                elif (ext in MATRIX_FILE_EXTS):
                    value['value'] = filename
                    value['source'] ="matrix"
                else:
                    raise SyntaxException

            elif value['type'] == "std::vector<cv::Mat>":
                # vector<cv::Mat>型のデータ指定は"ファイル名". ファイル名の拡張子で
                # 画像か行列かを見分ける

                # ファイル名を取得
                filename =self._getStackData(stack, 'STRING')
                filename = filename[1:len(filename)-1]
                root, ext = os.path.splitext(filename)

                # 画像データの場合
                if (ext in IMAGE_FILE_EXTS):
                    value['value'] = filename
                    value['source'] ="image"
                    self._getStackData(stack,'OPEN_SQUARE_BRACKET')
                    elemnum = self._getStackData(stack,'NAME')
                    if elemnum.isdigit() == False:
                        raise SyntaxException
                    value['elements']=int(elemnum)
                    self._getStackData(stack,'CLOSE_SQUARE_BRACKET')
                elif (ext in MATRIX_FILE_EXTS):
                    value['value'] = filename
                    value['source'] ="matrix"
                else:
                    raise SyntaxException

            elif value['type'] == "std::vector<cv::Point2f>" \
                or value['type'] == "std::vector<uchar>" \
                or value['type'] == "std::vector<float>":
                # ファイル名を取得
                filename =self._getStackData(stack, 'STRING')
                filename = filename[1:len(filename)-1]
                value['value'] = filename
            else:
                raise SyntaxException

        except SyntaxException as e:
            e.msg = 'Illegal initialdata element'
            raise

        return value



    # 関数の分析を行う
    def _analyzeFunction(self,stack):
        # 返り値を作成する
        function = createFunctionDict()

        try:
            # 次のトークン 関数型 を取得する
            function['return'] = self._getStackDataType(stack)

            # 次の トークン 属性記号 を取得する
            self._getStackData(stack, 'ATTRIBUTE')

            # 属性を分析する
            token = stack[0]
            value = self._getStackData(stack, 'NAME', 'Invalid function attribute')

            # 属性のチェックを行う
            if is_ret_attribute(value):
                function['attr'] = value
            else:
                raise AttributeError(token, 'Invalid function attribute')

            # 次のトークン 関数名 を取得する
            function['name'] = self._getStackData(stack, 'NAME')

            # 次のトークンが'/'である場合、作者が記述される
            token = stack.pop(0)
            if (token.type == 'SLASH'):
                # 作者抽出

                # defaultの存在チェック
                if (stack[0].type == 'SEPARATOR'):
                    # "default"を足す
                    stack.pop(0)
                    function['authors'].append("default")

                while(True):
                    token = stack.pop(0)
                    if (token.type == 'NAME'):
                        # 作者名を足す(重複は許可しない)
                        if (token.value in function['authors']):
                            # 不正
                            raise SyntaxException(token,'Multiple definition of author:%s'%token.value)
                        else:
                            function['authors'].append(token.value)
                            if (stack[0].type == 'SEPARATOR'):
                                # 継続
                                stack.pop(0)
                                pass
                    elif (token.type == 'OPEN_PAREN'):
                        # 終了
                        break
                    else:
                        # 不正
                        raise SyntaxException(token,'Invalid type token:%s'%token.type)

            elif (token.type=='OPEN_PAREN'):
                # 作者として"default"を加える
                function['authors'].append("default")
                # パラメータの分析を行っていく
                pass
            else:
                # 不正
                raise SyntaxException(token,'')

            # パラメータの分析
            while True:
                # パラメータの分析を行う
                param = self._analyzeParameter(stack, function)
                function['params'].append(param)

                # 引数の終了位置を取得する
                token = stack.pop(0)
                if token.type == 'CLOSE_PAREN':
                    break

        except SyntaxException as e:
            print e
            raise
        except DataTypeException as e:
            print e
            raise
        except AttributeException as e:
            print e
            raise

        return function


    # 関数のパラメータの分析を行う
    def _analyzeParameter(self, stack, function):
        # 返り値を作成する
        parameter = createParameterDict()

        try:
            # 次のトークン パラメータ型 を取得する
            parameter['type'] = self._getStackDataType(stack)

            # 次のトークン 参照 or ポインタ を取得する
            token = stack[0]
            if token.type == 'REFERENCE':
                parameter['reference'] = True
                token = stack.pop(0)
            elif token.type == 'POINTER':
                parameter['pointer'] = True
                token = stack.pop(0)

            # 次のトークン パラメータ名 を取得する
            parameter['name'] = self._getStackData(stack, 'NAME')

            # 次のトークン 属性記号 を取得する
            self._getStackData(stack, 'ATTRIBUTE')

            # 属性を分析する
            token = stack[0]
            value = self._getStackData(stack, 'NAME', 'Invalid attribute')

            # inport属性を解析する
            if value == 'inport':
                parameter['attr'] = value
                # 初期条件、初期データの解析
                self._analyzeInport(stack, parameter, function)

            # outport属性を解析する
            elif value == 'outport':
                parameter['attr'] = value

            # param属性を解析する
            elif value == 'param':
                parameter['attr'] = value
                self._analyzeInitValue(stack, parameter)

            # list属性を解析する
            elif value == 'list':
                parameter['attr'] = value
                self._getStackData(stack, 'SLASH', 'Invalid list')
                parameter['option'] = self._getStackData(stack, 'NAME', 'Invalid list')
                self._analyzeInitValue(stack, parameter)

            # 例外
            else:
                raise SyntaxException(token,'Unknown Attribute')

        except SyntaxException:
            raise
        except DataTypeException:
            raise
        except AttributeException:
            raise
        except:
            print "error : parameter"

        return parameter

    # inportの分析を行う
    def _analyzeInport(self, stack, parameter, function):
        if stack[0].type == 'SLASH':
            self._getStackData(stack, 'SLASH')

            # 初期条件式の抽出
            cond = []

            # 初期条件記述の抽出
            cond.append(stack[0])
            self._getStackData(stack, 'OPEN_PAREN')
            paren_count = 1

            invalid_token = ('OPEN_BRACE','CLOSE_BRACE','OPEN_SQUARE_BRACKET',
                            'CLOSE_SQUARE_BRACKET','SEMI_COLON','REFERENCE',
                            'SEPARATOR','ATTRIBUTE','STRING')

            for count in range( len(stack) ):
                token = stack.pop(0)
                cond.append(token)
                if token.type == 'OPEN_PAREN':
                    paren_count += 1
                elif token.type == 'CLOSE_PAREN':
                    paren_count -= 1
                    if paren_count == 0:
                        break
                elif token.type in invalid_token:
                    raise SyntaxException(token,"invalid expression")

            # 条件式文字列を生成する <= _WHOLE_COUNTER_やconfigの作成
            configcnt=1
            option = ""
            for cnt in range(len(cond)):
                if cond[cnt].type=='OPEN_PAREN':
                    if cond[cnt+1].type == 'CLOSE_PAREN':
                        raise SyntaxException(cond[cnt+1], "Illegal expression")
                    else:
                        option += cond[cnt].value

                elif cond[cnt].type=='NAME':
                    # (整数) の場合、Configurationを作成する
                    if (cond[cnt-1].type == 'OPEN_PAREN') & (cond[cnt].value.isdigit()) & (cond[cnt+1].type == 'CLOSE_PAREN'):
                        configname =parameter['name']+"_%d"%configcnt
                        # Configuration作成
                        self._appendFuncConfig(function,'long', configname, cond[cnt].value )
                        configcnt+=1
                        option += "p_%s->getValue()"%configname
                    else:
                        # 警告
                        # print "There is a possibility that grammar is mistaken. : lineno=>%s value=>%s"%(cond[cnt].lineno,cond[cnt].value)
                        option += cond[cnt].value

                elif cond[cnt].type=='KEYWORD':
                    if cond[cnt].value == "$(C_SC)":
                        option += "STEPWISE_GET_COMMON_STEP_COUNTER()"
                    elif cond[cnt].value == "$(I_SC)":
                        option += "STEPWISE_GET_INDIVIDUAL_STEP_COUNTER(this)"
                    else:
                        # $(初期データ.size)
                        r = re.compile(r'\$\(\ *([a-zA-Z0-9_]*)\.size\ *\)')
                        m = r.match(cond[cnt].value)
                        inidataname = m.group(1)
                        inidata = self._getInitialdata(inidataname)
                        if (inidata == None):
                            raise SyntaxException(cond[cnt], 'Undefined data "%s" used.'%inidataname)
                        else:
                            if ( inidata['type']=='cv::Mat'):
                                raise SyntaxError('"%s" is not vector data'%inidata['name'])
                            else:
                                # 使用するデータ名をコンフィギュレーションとして登録
                                self._appendFuncConfig(function,'std::string', inidata['name'], '"%s"'%inidata['value'] )

                                if (inidata['type']=='std::vector<cv::Mat>' and inidata['source']=='image'):
                                    # イメージの配列の場合、サイズも登録して、サイズに置き換える
                                    self._appendConfig(function['name'],'long', inidata['name']+"_size", inidata['elements'] )
                                    option += '(((ParameterT<long> *)getParam("%s_size"))->getValue())'%(inidata['name'])

                                elif (inidata['type']=='std::vector<cv::Mat>' and inidata['source']=='matrix'):
                                    option += 'MatrixUtil::getMatrixVecLength(((ParameterT<std::string> *)getParam("%s"))->getValue())'%(inidata['name'])

                                elif (inidata['type']=='std::vector<cv::Point2f>'):
                                    option += 'MatrixUtil::getPoint2fVecLength(((ParameterT<std::string> *)getParam("%s"))->getValue())'%(inidata['name'])

                                elif (inidata['type']=='std::vector<uchar>'):
                                    option += 'MatrixUtil::getUcharVecLength(((ParameterT<std::string> *)getParam("%s"))->getValue())'%(inidata['name'])

                                elif (inidata['type']=='std::vector<float>'):
                                    option += 'MatrixUtil::getFloatVecLength(((ParameterT<std::string> *)getParam("%s"))->getValue())'%(inidata['name'])

                                else:
                                    # 発生しない
                                    raise Exception('Unknown error.')

                else:
                    option += cond[cnt].value

            parameter['option'] = option

            # 初期データの抽出
            self._getStackData(stack, 'EQUAL')
            parameter['value'] = self._getStackData(stack, 'NAME')

    # 初期値の分析を行う
    def _analyzeInitValue(self, stack, parameter):
        # 次のトークン = を取得する
        self._getStackData(stack, 'EQUAL')

        init_value = ""
        paren_count = 0
        brace_count = 0

        # 初期値の分離を行う
        for count in range( len(stack) ):
            token = stack[count]
            if token.type == 'OPEN_BRACE':
                brace_count += 1
            elif token.type == 'CLOSE_BRACE':
                brace_count -= 1
            elif token.type == 'OPEN_PAREN':
                paren_count += 1
            elif token.type == 'CLOSE_PAREN':
                paren_count -= 1
                if paren_count < 0:
                    break
            elif token.type == 'SEPARATOR':
                if brace_count == 0 and paren_count == 0:
                    break

        # 初期化文字列を生成する
        for var in range(count):
            token = stack.pop(0)
            init_value += token.value

        # 初期値を設定する
        parameter['value'] = init_value


    # 指定した名前のFunction辞書が存在するかを調べる
    def _getFunction(self, name):
        for func in self.function_list:
            if func['name'] == name:
                return func
        return None

    # 指定した名前のEnum辞書が存在するかを調べる
    def _getEnum(self, enum_list, name):
        for enum in enum_list:
            if enum['name'] == name:
                return enum
        return None

    # 指定した名前のEnum辞書が存在するかを調べる
    def _getEnumElement(self, enum, name):
        for param in enum['params']:
            if param['name'] == name:
                return param
        return None

    # 指定した名前のInitialdataが存在するかを調べる
    def _getInitialdata(self, name):
        if len(self.initialdata_list) > 0:
            for data in self.initialdata_list[0]:
                if data['name'] == name:
                    return data
        return None

    # LIST属性の初期値が正しいかのチェックを行う
    def _validateListAttribute(self, enum_list, function):
        # LIST属性のパラメータに対する調査を行う
        for param in function['params']:
            if param['attr'] == 'list':
                # list属性で指定されたEnumが存在するかを調べる
                enum = self._getEnum(enum_list, param['option'])
                if enum == None:
                    msg = ('Unknown enum %s in function %s.')%(param['option'], function['name'])
                    raise SyntaxException(None, msg)

                # 設定された初期値が存在するかを調べる
                element = self._getEnumElement(enum, param['value'])
                if element == None:
                    msg = ('Unknown enum key %s in %s enum in function %s.')%(param['value'], param['option'], function['name'])
                    raise SyntaxException(None, msg)

                param['detail'] = ('%s:%s')%(element['name'], element['value'])

    # INPORT属性の初期条件、初期データが正しいかのチェックを行う
    def _validateInPortInitialData(self, enum_list, function):
        # inport属性のパラメータに対する調査を行う
        for param in function['params']:
            if param['attr'] == 'inport':
                if param['option'] != 'None':
                    # 初期データ使用条件が存在するため、データの定義チェックを行う
                    data = self._getInitialdata(param['value'])
                    if data == None:
                        msg = ('Unknown data %s in inport %s at function %s.')%(param['value'], param['name'], function['name'])
                        raise SyntaxException(None, msg)
                    else:
                        # 初期データが存在する場合、初期データはコンフィギュレーションとする
                        self._appendConfig(function['name'], "std::string", data['name'], '"%s"'%data['value'] )

                        # 初期データがイメージデータの配列の場合、サイズもコンフィギュレーションとする
                        if( (data['type'] == "std::vector<cv::Mat>") and (data['source'] == "image") ):
                            self._appendConfig(function['name'], "long", data['name']+"_size", data['elements'] )


    def _appendConfig(self, funcname,typename, name, value ):
        function = self._getFunction(funcname)
        if(function != None):
            self._appendFuncConfig(function, typename, name, value )

    def _appendFuncConfig(self, function, typename, name, value):
        # 既に同じ名前のconfigが存在するか確認する
        config_already_exist = False
        for config in function['configs']:
            if (config['name']==name):
                config_already_exist = True
                break
        if (config_already_exist==True):
            pass # 既に同じ名前のコンフィギュレーションが存在していたら、登録しない
        else:
            config = createConfigDict()
            config['type']=typename
            config['name']=name
            config['value']=value
            function['configs'].append(config)

