#ifndef OPENCV_WRAPPER_H
#define OPENCV_WRAPPER_H

#include <opencv2/opencv.hpp>

/*!
 * @brief cv::distanceTransform�̃��b�p�[�֐�
 */
void distanceTransformWrapper( const cv::Mat& src, cv::Mat& dst, int distanceType, int maskSize );

/*!
 * @brief cv::distanceTransform�̃��b�p�[�֐�
 */
void distanceTransformWrapperWithLabels( const cv::Mat& src, cv::Mat& dst, cv::Mat& labels, int distanceType, int maskSize, int labelType );

/*!
 * @brief cv::imshow�̃��b�p�[�֐�
 */
void show_image( const std::string& win_name, const cv::Mat& src );


#endif //OPENCV_WRAPPER_H