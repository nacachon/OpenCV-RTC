// This file is created automatically.

#ifndef _MYLOOPBACKCONDITIONMANAGER_H_
#define _MYLOOPBACKCONDITIONMANAGER_H_

#include <LoopBackCondition.h>

class LoopBackConditionload_image_seq_default : public LoopBackCondition
{
public:
    LoopBackConditionload_image_seq_default(RTC::RTObject_impl &obj)
        : LoopBackCondition( obj ){};
    virtual ~LoopBackConditionload_image_seq_default(){};
    bool useInitialData( const std::string & portname );
    void getInitialData( const std::string & portname );
};

class LoopBackConditionsave_image_seq_default : public LoopBackCondition
{
public:
    LoopBackConditionsave_image_seq_default(RTC::RTObject_impl &obj)
        : LoopBackCondition( obj ){};
    virtual ~LoopBackConditionsave_image_seq_default(){};
    bool useInitialData( const std::string & portname );
    void getInitialData( const std::string & portname );
};

class LoopBackConditioncvRetina_default : public LoopBackCondition
{
public:
    LoopBackConditioncvRetina_default(RTC::RTObject_impl &obj)
        : LoopBackCondition( obj ){};
    virtual ~LoopBackConditioncvRetina_default(){};
    bool useInitialData( const std::string & portname );
    void getInitialData( const std::string & portname );
};

#endif // _MYLOOPBACKCONDITIONMANAGER_H_