#ifndef FUNCTION_LIST_VIEW_INTERFACE_H
#define FUNCTION_LIST_VIEW_INTERFACE_H

#include <string>
#include <vector>

/*!
 * @brief �R�[���o�b�N��ݒ肷�邽�߂̊֐�
 */
__declspec(dllimport) void FunctionListView_setCallbacks( 
	void (*save_callback)(const std::string&), 
	void (*create_callback)(const std::string&),
	void (*load_callback)(const std::string&)
	);


/*!
 * @brief �t�H�[�����쐬���邽�߂̊֐�
 */
__declspec(dllimport) void FunctionListView_createForm( std::vector<std::string>& func_list );


#endif //FUNCTION_LIST_VIEW_INTERFACE_H